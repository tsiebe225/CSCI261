#include "date.h"
#include <string>
#include<math.h>

int main() {
    Date unloaded;
    unloaded.PrintDate();

    Date loadedDate(05, 18, 1996);
    loadedDate.PrintDate();


    cout << loadedDate.EarlierDate(unloaded) << endl;
    cout << unloaded.EarlierDate(loadedDate) << endl;


    cout<<loadedDate.GetDay()<<endl;
    cout<<loadedDate.GetMonth()<<endl;
    cout << loadedDate.GetYear() << endl;;

    loadedDate.SetDay(30);
    loadedDate.SetMonth(6);
    loadedDate.SetYear(2000);

    cout << loadedDate.GetDay() << endl;
    cout << loadedDate.GetMonth() << endl;
    cout << loadedDate.GetYear() << endl;

    loadedDate.SetDay(33);
    loadedDate.SetMonth(13);
    loadedDate.SetYear(-5);

    cout << loadedDate.GetDay() << endl;
    cout << loadedDate.GetMonth() << endl;
    cout << loadedDate.GetYear() << endl;

    loadedDate.PrintDate();
    return 0;
}