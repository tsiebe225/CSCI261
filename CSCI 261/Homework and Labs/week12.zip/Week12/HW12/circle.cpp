#include "Circle.h"
Circle::Circle(double x, double y,Color color) { //loaded
    this->x = x;
    this->y = y;
    this->color = color;
}


void Circle::update() {
    x += x_movement;
    y += y_movement;
}


bool Circle::checkCollision(Circle& otherCircle) {

    if (circleShape.getGlobalBounds().intersects(otherCircle.circleShape.getGlobalBounds())) {
            
        return true;
    }

    else {
        return false;
    }

}

void Circle::changeDirection(Circle& otherCircle) {
    x_movement = -x_movement;
    y_movement = -y_movement;

}


void Circle::checkAndUpdateWallCollision() {

    if (x + (r * 2) >= xScreen || x + (r * 2) <= 0) { //if ball hits horiztonal boundary reverse horizontal direction
        x_movement = -x_movement;
    }

    if (y + (r * 2) >= yScreen || y + (r * 2) <= 0) { //if ball hits vertical boundary reverse vertical direction
        y_movement = -y_movement;
    }

}

Color Circle::getColor() {
    return color;
}

double Circle::getX() {
    return x;
}
double Circle::getY() {
    return y;
}

void Circle::setDirection(double x, double y) {
    x_movement = x;
    y_movement = y;
}

void Circle::setColor(Color color) {
    this->color = color;
}
double Circle::getXDirection() {
    return x_movement;
}
double Circle::getYDirection() {
    return y_movement;
}