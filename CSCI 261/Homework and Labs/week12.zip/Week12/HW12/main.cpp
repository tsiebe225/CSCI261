/* HW12
*
* Tanner Siebe
*
* 
*
* Makes circles bounce around on screen
*
*/

#include <iostream>
#include "Circle.h"
#include <cmath>
#include <random>
using namespace std;

#include <SFML/Graphics.hpp>
#include <SFML/Window/Mouse.hpp>
using namespace sf;

const int NUMBER_OF_CIRCLES = 4;
const int WINDOW_X = 640;
const int WINDOW_Y = 640;
const int RADIUS = 20;


vector<Circle> allCircles;


/*I was having issues getting the circles to run and move, sadly CTLM was crowded and I was unable to get any help moving forward on the
HW and if you can give me some feedback on how to proceed that would be apprecaited as I liked the challenge of this lab,
my partner who I started this with was able to figure it out but I sadly was not able to do so given time limitations placed on me.
Any feedback on how to make this work better would be appreciated.*/

/*
-----------------------------------------------------------------------
OBJECTIVE 1
--------------------------------------------------------------------
*/
void createCircleObject() {

    Color color;
    double z, w;

    double x = (rand() % WINDOW_X - RADIUS) + 1; //sets location to start
    double y = (rand() % WINDOW_Y - RADIUS) + 1;

    for (int i = 0; i < allCircles.size(); ++i) {

        for (int j = i; j >= 0; --j) { 
                                       
            while (pow(allCircles[j].getX() - x, 2) + pow(allCircles[j].getY() - y, 2) <= pow(RADIUS * 2, 2)) {
                x = (rand() % WINDOW_X - 1) + 1;
                y = (rand() % WINDOW_Y - 1) + 1;
            }

        }

    }

    switch ((rand() % 5) + 1) { //col gen
    case 1:
        color = Color::Cyan;
        break;
    case 2:
        color = Color::Magenta;
        break;
    case 3:
        color = Color::White;
        break;
    case 4:
        color = Color::Red;
        break;
    case 5:
        color = Color::Yellow;
        break;
    }

    Circle ball(x, y, color); //creates object

    do {
        z = (rand() % 14) - 5; //movement
        w = (rand() % 14) - 5;

    } while (z == 0 || w == 0); //check


    ball.setDirection(z, w);

    allCircles.push_back(ball); //vector

}


int main() {
    srand(time(NULL));


    /*
    -----------------------------------------------------------------------
    OBJECTIVE 2
    --------------------------------------------------------------------
    */

    for (int i = 0; i < NUMBER_OF_CIRCLES; ++i) {
        createCircleObject();
    } 


      
    RenderWindow window(VideoMode(WINDOW_X, WINDOW_Y), "SFML Template");

    
    while (window.isOpen()) {

        
        window.clear();





        /*
        -----------------------------------------------------------------------
        OBJECTIVE 3
        --------------------------------------------------------------------
        */

        for (int i = 0; i < allCircles.size(); ++i) { 

            for (int j = 0; j < allCircles.size(); ++j) { 

                if (i != j) { 

                    if (allCircles[i].checkCollision(allCircles[j])) {

                        allCircles[i].changeDirection(allCircles[j]);

                    }

                }

            }

        }


        /*
        -----------------------------------------------------------------------
        OBJECTIVES 4 & 5
        --------------------------------------------------------------------
        */

        for (int i = 0; i < allCircles.size(); ++i) { //checks if ball has collided with the window "walls"
            allCircles[i].checkAndUpdateWallCollision();
        }

        for (int i = 0; i < allCircles.size(); ++i) { //moves the ball
            allCircles[i].update();
        }


        /*
        -----------------------------------------------------------------------
        OBJECTIVE 6
        --------------------------------------------------------------------
        */

        for (int i = 0; i < allCircles.size(); ++i) { //draws the circles

            allCircles[i].circleShape.setPosition(float(allCircles[i].getX()), float(allCircles[i].getY()));
            allCircles[i].circleShape.setRadius(float(RADIUS));
            allCircles[i].circleShape.setFillColor(allCircles[i].getColor());
            window.draw(allCircles[i].circleShape
);

        }

      
        window.display();


        Event click;

        while (window.pollEvent(click)) {
            if (click.type == Event::Closed) {
                window.close();
            }

        }

    }

    return EXIT_SUCCESS;
}