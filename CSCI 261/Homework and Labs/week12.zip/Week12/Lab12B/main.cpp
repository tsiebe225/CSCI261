#include <math.h>
#include<string>
#include<array>
#include<iostream>
#include<fstream>

#include"date.h"
#include "MyDate.h"

using namespace std;


int main() {
    ifstream dateData("dates.txt");
    if (dateData.fail()) {
        cerr << "Error opening input file" << endl;
        exit(1);
    }
    MyDate MyDates[7];
    int inputMonth;
    int inputDay;
    int inputYear;
    char slash;
    string inputName;
    int inputAge;
    int inputRating;
    int i = 0;

    while (!dateData.eof()) {
        dateData >> inputMonth;
        dateData >> slash;
        dateData >> inputDay;
        dateData >> slash;
        dateData >> inputYear;
        dateData >> inputName;
        dateData >> inputAge;
        dateData >> inputRating;



        Date date(inputMonth, inputDay, inputYear);
        MyDate myDate(date, inputName, inputAge, inputRating);

       MyDates[i] = myDate;
        i = i + 1;

        
        if (i == 7)
            break;
    }
    for (int j = 0; j < 7; ++j) {
        if (MyDates[j].GetRating()==5){
            cout << MyDates[j].PrintDate(MyDates[j]) << endl;

        }
    }


     
    dateData.close();


    return 0;
}