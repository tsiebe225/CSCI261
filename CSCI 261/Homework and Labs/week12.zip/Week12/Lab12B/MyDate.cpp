//Lab12B
//Tanner Siebe


#include "date.h"
#include "MyDate.h"
#include<string>
#include<iostream>


using namespace std;

MyDate::MyDate() {
    dateTime = Date();
    name = "Unknown";
    age = 18;
    rating = 3;
}
MyDate::MyDate(Date date, string name, int age, int rating) {
    if ((rating > 0) && (rating < 6)) {
        this->rating = rating;
    }
    else {
        this-> rating = 3;
    }
    this->name = name;
    this->dateTime = date;
    if (age >= 18) {
        this->age = age;
    }
    else {
        this->age = 18;
    }

}

string MyDate::PrintDate(MyDate dateInfo) {
    cout << "Date: " << dateInfo.dateTime.GetMonth() << "/" << dateInfo.dateTime.GetDay()<<"/" << dateInfo.dateTime.GetYear() << endl;
    cout << "Name: " << dateInfo.GetName() << endl;
    cout << "Age:" << dateInfo.GetAge() << endl;
    cout << "Rating: " << dateInfo.GetRating() << endl;
    return "  ";
}
string MyDate::GetName() {
    return name;
}
int MyDate::GetAge() {
    return age;
}
int MyDate::GetRating() {
    return rating;
}
void MyDate::SetAge(int ageInput) {
    if (ageInput >= 18) {
        this->age = ageInput;
    }
    else {
        age = 18;
    }
    return;
}
void MyDate::SetName(string nameInput) {
    name = nameInput;
}
void MyDate::SetRating(int ratingInp) {
    if ((rating > 0) && (rating < 6)) {
        rating = ratingInp;
    }
    else {
        rating = 3;
    }
}
void MyDate::SetDate(Date dateInp) {
    dateTime = dateInp;
}