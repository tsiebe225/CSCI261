#include "date.h"
#include <string>
#include<math.h>
#include<iostream>

using namespace std;



Date::Date() {
    day = defaultDay;
    month = defaultMonth;
    year = defaultYear;
}
Date::Date(int monthInp, int dayInp, int yearInp) {
    day = dayInp;
    month = monthInp;
    year = yearInp;
    if ((day == 1) && (month == 8) && (year == 1876)) {

        cout << "8/1/1876 is the day Colorado becomes a state." << endl;
    }
    ValidDate();
}
void Date::ValidDate() {
    if (year < 0) {
        day = defaultDay;
        month = defaultMonth;
        year = defaultYear;
    }
    if ((month < 0) || (month>12)) {
        day = defaultDay;
        month = defaultMonth;
        year = defaultYear;
    }
    if ((day < 0) || (day>31)) {
        day = defaultDay;
        month = defaultMonth;
        year = defaultYear;
    }
    return;
}
void Date::SetDay(int daySet) {
    day = daySet;
    ValidDate();
}
void Date::SetMonth(int monthSet) {
    month = monthSet;
    ValidDate();
}
void Date::SetYear(int yearInp) {
    year = yearInp;
    ValidDate();
}
int Date:: GetDay() {
    return day;
}
int Date::GetMonth() {
    return month;
}
int Date::GetYear() {
    return year;
}
bool Date::EarlierDate(Date sampleDate) {
    if (sampleDate.year > year) {
        return true;
    }
    else if (year > sampleDate.year) {
        return false;
    }
    else if (year == sampleDate.year) {
        if (month>sampleDate.month){
            return false;
        }
        else if (sampleDate.month > month) {
            return true;
        }
        else if (sampleDate.month == month) {
            if (day > sampleDate.day) {
                return false;
            }
            else if (sampleDate.day > day) {
                return true;
            }
            else if (day == sampleDate.day) {
                return false;
            }
        }
    }
}
string Date::PrintDate() {
    cout << month << "/" << day << "/" << year << endl;
    return"";
}
