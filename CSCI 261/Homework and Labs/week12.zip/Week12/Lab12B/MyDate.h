#pragma once

#include<string>
#include"date.h"
#include<iostream>
#include<fstream>

using namespace std;


class MyDate {
public:
    MyDate();
    MyDate(Date date, string name, int age, int rating);

    string PrintDate(MyDate dateInfo);
    void SetName(string name);
    void SetRating(int ratingInput);
    void SetAge(int ageInput);
    void SetDate(Date dateTime);

    string GetName();
    int GetAge();
    int GetRating();





private:
    Date dateTime;
    int age;
    int rating;
    string name;
};