#pragma once

#include <string>
#include<iostream>

using namespace std;

class Date {

    public:
        Date();
        Date(int monthInp, int dayInp, int yearInp);

        void SetDay(int daySet);
        void SetMonth(int monthSet);
        void SetYear(int yearSet);

        int GetDay();
        int GetMonth();
        int GetYear();

        string PrintDate();

        bool EarlierDate(Date sampleDate);

        static const int defaultDay = 30;
        static const int defaultMonth = 12;
        static const int defaultYear = 1950;


    private:
        int day;
        int month;
        int year;

        void ValidDate();



};