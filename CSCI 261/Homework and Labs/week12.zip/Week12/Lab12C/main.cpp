//Lab12C
//Tanner Siebe


#include<fstream>
#include<iostream>

using namespace std;

int nums[1000];

bool NumSearch(int input, int low, int high) {
    int middle = (low + high) / 2;
    if (input == nums[middle]) {
        return true;
    }
    if (low >= high) {
        return false;//stops infinite loop if out of range guess
    }
    else {
        if (input < nums[middle]) {
            NumSearch(input, low, middle-1);
        }
        else if (input>nums[middle]) {
            NumSearch(input, (middle + 1), high);
        }
    }
}


int main() {
    int userGuess;
    int holder;
    int z = 0;

    ifstream numList("nums.txt");
    if (numList.fail()) {
        cerr << "Error opening input file" << endl;
        exit(1);
    }
    while (!numList.eof()) {
        numList >> holder;

        if (z < sizeof(nums)) {
            nums[z] = holder;
        }
        ++z;
    }
    cout << "Please put in a value to search for:  " << endl;
    cin >> userGuess;

    if (NumSearch(userGuess, 0, sizeof(nums))) {
        cout << userGuess << " was found in the list" << endl;
    }
    else {
        cout << userGuess << " was not in the list" << endl;
    }

    numList.close();
    return 0;
}