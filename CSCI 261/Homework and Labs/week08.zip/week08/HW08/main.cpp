//Author:Tanner Siebe
//CSCI261
// HW08
#include <iostream> 
#include <array>
using namespace std;

#include <SFML/Graphics.hpp>                                        // SFML Library
using namespace sf;

// GLobal Variables (constants)
const string IMAGE_FILE = "data/columbine.png";                     // Path to our image
const int IMAGE_WIDTH = 250;                                        // width of our image
const int IMAGE_HEIGHT = 262;                                       // height of our image
const double RED_WEIGHT = .299;
const double GREEN_WEIGHT = .587;
const double BLUE_WEIGHT = .114;

                                                                    /***** DEFINE YOUR FUNCTION PROTOTYPES BELOW HERE *****/
void getPixels(Image image, Color colors[IMAGE_WIDTH][IMAGE_HEIGHT]);
void setPixels(Color colors[IMAGE_WIDTH][IMAGE_HEIGHT], Image &image);
void doNegative(Color colors[IMAGE_WIDTH][IMAGE_HEIGHT]);
void doGrayScale(Color colors[IMAGE_WIDTH][IMAGE_HEIGHT]);
void doSpecial(Color colors[IMAGE_WIDTH][IMAGE_HEIGHT]);




                                                                    /***** DEFINE YOUR FUNCTION PROTOTYPES ABOVE HERE *****/

int main() {

    // The Original Image
    Image originalImage;                                            // creates an image object
    if (!originalImage.loadFromFile("data/columbine.png")) {                // loads the image file into the object
        cerr << "Couldn't open image file!" << endl;
        return EXIT_FAILURE;
    }
    Texture originalTexture;                                        // create a texture object
    originalTexture.loadFromImage(originalImage);                   // load our first image into this texture
    Sprite originalSprite;                                          // create a sprite object
    originalSprite.setTexture(originalTexture);                     // apply our first texture to this sprite
    originalSprite.setPosition(Vector2f(0, 0));                     // place this sprite in the upper left corner

                                                                    // The Negated Image
    Image negatedImaged;                                            // creates an image object
    if (!negatedImaged.loadFromFile(IMAGE_FILE)) {                // loads the image file into the object
        cerr << "Couldn't open image file!" << endl;
        return EXIT_FAILURE;
    }
    Color negPxels[IMAGE_WIDTH][IMAGE_HEIGHT];                      // create a 2D array of Color objects
    getPixels(negatedImaged, negPxels);                             // get the pixels from our image to be negated
    doNegative(negPxels);                                           // negate the pixels
    setPixels(negPxels, negatedImaged);                             // set the pixels of our negated image
    Texture negatedTexture;                                         // create a texture object
    negatedTexture.loadFromImage(negatedImaged);                    // load our second image into this texture
    Sprite negatedSprite;                                           // create a sprite object
    negatedSprite.setTexture(negatedTexture);                       // apply our second texture to this sprite
    negatedSprite.setPosition(Vector2f(IMAGE_WIDTH, 0));            // place this sprite in the upper right corner

                                                                    // The Grayscale Image
    Image grayscaleImage;                                           // creates an image object
    if (!grayscaleImage.loadFromFile(IMAGE_FILE)) {               // loads the image file into the object
        cerr << "Couldn't open image file!" << endl;
        return EXIT_FAILURE;
    }
    Color greyPxels[IMAGE_WIDTH][IMAGE_HEIGHT];                     // create a 2D array of Color objects
    getPixels(grayscaleImage, greyPxels);                           // get the pixels from our image to be grayscaled
    doGrayScale(greyPxels);                                         // grayscale the pixels
    setPixels(greyPxels, grayscaleImage);                           // set the pixels of our grayscale image
    Texture grayscaleTexture;                                       // create a texture object
    grayscaleTexture.loadFromImage(grayscaleImage);                 // load our third image into this texture
    Sprite grayscaleSprite;                                         // create a sprite object
    grayscaleSprite.setTexture(grayscaleTexture);                   // apply our third texture to this sprite
    grayscaleSprite.setPosition(Vector2f(0, IMAGE_HEIGHT));         // place this sprite in the lower left corner

                                                                    // The Special Image
    Image specialImage;                                             // creates an image object
    if (!specialImage.loadFromFile(IMAGE_FILE)) {                 // loads the image file into the object
        cerr << "Couldn't open image file!" << endl;
        return EXIT_FAILURE;
    }
    Color specialPixels[IMAGE_WIDTH][IMAGE_HEIGHT];                 // create a 2D array of Color objects
    getPixels(specialImage, specialPixels);                         // get the pixels from our image to be specialized
    doSpecial(specialPixels);                                       // specialize the pixels
    setPixels(specialPixels, specialImage);                         // set the pixels of our special image
    Texture specialTexture;                                         // create a texture object
    specialTexture.loadFromImage(specialImage);                     // load our fourth image into this texture
    Sprite specialSprite;                                           // create a sprite object
    specialSprite.setTexture(specialTexture);                       // apply our fourth texture to this sprite
    specialSprite.setPosition(Vector2f(IMAGE_WIDTH, IMAGE_HEIGHT)); // place this sprite in the lower right corner

                                                                    // creates the window object with a WIDTH*2xHEIGHT*2 resolution window
    RenderWindow window(VideoMode(IMAGE_WIDTH * 2, IMAGE_HEIGHT * 2), "Homework 08");

    // Draw loop: Each iteration of this loop draws a single frame
    while (window.isOpen()) {

        // Erase the screen with black (because space)
        window.clear();

        window.draw(originalSprite);                                // draw the original sprite to the screen
        window.draw(negatedSprite);                                 // draw the negated sprite to the screen
        window.draw(grayscaleSprite);                               // draw the grayscale sprite to the screen
        window.draw(specialSprite);                                 // draw the special sprite to the screen

                                                                    // Apply all the draws to the screen
        window.display();

        // check for a closed window event
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed)
                window.close();
        }
    }

    return EXIT_SUCCESS;
}

/***** PLACE YOUR FUNCTION DEFINITIONS BELOW HERE *****/

void getPixels(Image image, Color colors[IMAGE_WIDTH][IMAGE_HEIGHT]) {
    for (int j = 0; j < IMAGE_HEIGHT; ++j) {
        for (int k = 0; k < IMAGE_WIDTH; ++k) {
            colors[k][j] = image.getPixel(k,j);
        }
    }
    return;
}

void setPixels(Color colors[IMAGE_WIDTH][IMAGE_HEIGHT], Image &image) {
    for (int j = 0; j < IMAGE_HEIGHT; ++j) {
        for (int k = 0; k < IMAGE_WIDTH; ++k) {
            image.setPixel(k, j, colors[k][j]);
        }
    }
}

void doNegative(Color colors[IMAGE_WIDTH][IMAGE_HEIGHT]) {
    for (int j = 0; j < IMAGE_HEIGHT; ++j) {
        for (int k = 0; k < IMAGE_WIDTH; ++k) {
            colors[k][j].r = 255 - colors[k][j].r;
            colors[k][j].g = 255 - colors[k][j].g;
            colors[k][j].b = 255 - colors[k][j].b;
        }
    }
}

void doGrayScale(Color colors[IMAGE_WIDTH][IMAGE_HEIGHT]) {
        int ave;
    for (int j = 0; j < IMAGE_HEIGHT; ++j) {
        for (int k = 0; k < IMAGE_WIDTH; ++k) {
            ave = (RED_WEIGHT*colors[k][j].r + GREEN_WEIGHT*colors[k][j].g + BLUE_WEIGHT*colors[k][j].b)/3;
            colors[k][j].r = ave;
            colors[k][j].g = ave;
            colors[k][j].b = ave;
        }
    }

}

void doSpecial(Color colors[IMAGE_WIDTH][IMAGE_HEIGHT]) {
    int aveR;
    int aveG;
    int aveB;
    for (int j = 0; j < IMAGE_HEIGHT; j=j+2) {
        for (int k = 0; k < IMAGE_WIDTH;k=k+2) {
            aveR = (colors[k][j].r + colors[k + 1][j + 1].r) / 2;
            aveG = (colors[k][j].g + colors[k + 1][j + 1].g) / 2;
            aveB = (colors[k][j].b + colors[k + 1][j + 1].b) / 2;
            colors[k][j].r = aveR;
            colors[k + 1][j + 1].r = aveR;
            colors[k][j].g = aveG;
            colors[k + 1][j + 1].g = aveG;
            colors[k][j].b = aveB;
            colors[k + 1][j + 1].b = aveB;
        }
    }
}