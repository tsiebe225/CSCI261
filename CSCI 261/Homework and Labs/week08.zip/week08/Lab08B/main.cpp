#include <iostream>
#include <cmath>
using namespace std;

#include <SFML/Graphics.hpp>
using namespace sf;

int main() {

    // creates the window object with an 640x640 resolution window
    RenderWindow window(VideoMode(640, 640, 32), "SFML Example");

    // Draw loop: Each iteration of this loop draws a single frame
    while (window.isOpen()) {

        window.clear(Color::Black);


        
        CircleShape star;
        star.setPosition(320, 20);
        star.setRadius(50);
        star.setFillColor(Color::White);
        window.draw(star);

        RectangleShape rect;
        rect.setSize(Vector2f(15, 200));
        rect.setPosition(362, 70);
        rect.setFillColor(Color::White);
        window.draw(rect);

        RectangleShape rect2;
        rect2.setSize(Vector2f(5, 100));
        rect2.setPosition(362, 150);
        rect2.setFillColor(Color::White);
        rect2.rotate(45);
        window.draw(rect2);

        RectangleShape rect3;
        rect3.setSize(Vector2f(5, 100));
        rect3.setPosition(370, 150);
        rect3.setFillColor(Color::White);
        rect3.rotate(360-45);
        window.draw(rect3);

        RectangleShape rect4;
        rect4.setSize(Vector2f(5, 100));
        rect4.setPosition(362, 265);
        rect4.setFillColor(Color::White);
        rect4.rotate(45);
        window.draw(rect4);

        RectangleShape rect5;
        rect5.setSize(Vector2f(5, 100));
        rect5.setPosition(370, 265);
        rect5.setFillColor(Color::White);
        rect5.rotate(360 - 45);
        window.draw(rect5);


        // Draw a text object called label 
        Font myFont;
        if (!myFont.loadFromFile("data\\arial.ttf"))
            return -1;
        Text label;
        label.setFont(myFont);
        label.setString("This is Bob");
        label.setPosition(250, 520);
        label.setColor(Color::White);
        window.draw(label);

        /***** END OF FILE PROCESSING AND DRAWING	*****/

        // Apply all the draws to the screen
        window.display();

        // Check for any events 
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
            else if (event.type == Event::KeyPressed) {
                if (Keyboard::isKeyPressed(Keyboard::Q)) {
                    window.close();
                }
            }
                    
                }
            }

    return EXIT_SUCCESS;
}
