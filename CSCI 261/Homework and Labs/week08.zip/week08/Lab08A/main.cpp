/* CSCI 261:
* Author: Tanner Siebe
*
*
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <string>
#include <iomanip>
#include <vector>

using namespace std;  // For standard namespace 

int main() {
    vector<char> charStore;
    char input='a';
    int a = 1;
    int b = 0;
    cout << "Enter as many letters as you would like, enter ! to quit" << endl;
    while (input != '!') {
        cout << "Enter a letter: ";
        cin >> input;
        if (input == '!') {
            break;
        }
        else {
            charStore.resize(a, input);
            a = a + 1;
        }
    }
    cout << "Great you entered: ";
    for (int b = 0; b < a-1; ++b) {
        cout << charStore.at(b);
    }
    cout << endl;
    cout << "The first character you entered was " << charStore.front() << endl;
    cout << "The last character you entered was " << charStore.back() << endl;

    return 0;

}