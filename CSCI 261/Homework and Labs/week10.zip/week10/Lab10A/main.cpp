//Author: Tanner Siebe
//Lab10A Working with data
//CSCI 261 3/29/16


#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
using namespace std;

const int WIDTH = 640;
const int HEIGHT = 640;

int main() {
    //inputs
    double xStar;
    double yStar;
    double starBrightness;

    //outputs
    int xPixel;
    int yPixel;


    double zStar;//Will be ignored
    int heneryDraper;
    int harvardRevised;

    ifstream starData("stars.txt");
    ofstream modData("ModifiedStars.txt");

    if (starData.fail()) {
        cerr << "Error opening input file";
        exit(1);
    }
    if (modData.fail()) {
        cerr << "Error opening output file";
        exit(1);
    }

    while (!starData.eof()) {
        starData >> xStar;
        starData >> yStar;
        starData >> zStar;
        starData >> starBrightness;
        starData >> heneryDraper;
        starData >> harvardRevised;

        if ((starBrightness >= 0.0) && (starBrightness <= 8.0)) {

            xPixel = (int)((xStar + 1)*WIDTH / 2);
            yPixel = (int)(((-1 * yStar) + 1)*HEIGHT / 2);

            modData << xPixel << "    " << yPixel << "   " << starBrightness << endl;

        }

    }

    return 0;
}