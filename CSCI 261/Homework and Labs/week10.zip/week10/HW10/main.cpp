#include <iostream>
using namespace std;

#include <SFML/Graphics.hpp>
using namespace sf;

#include<fstream>
#include<string>
#include<math.h>

const int columnWidth = 20;
const int columnPlaceHeight = 100;
const float countHeightRatio = (640.0/15394);
void genFreq(int arrPlace[26]);
string charToString(int a);


int main() {

    string labelLet = "a";
 
    int numLetters[26];
    
    for (int z = 0; z < 26; ++z) {
        numLetters[z] = 0;
    }

    genFreq(numLetters);


    RenderWindow window(VideoMode(640, 640), "SFML Template");

    
    while (window.isOpen()) {

        Font myFont;
        if (!myFont.loadFromFile("data\\arial.ttf")) {
            return -1;
        }

        window.clear();

        for (int a = 0; a < 26; ++a) {
            RectangleShape bar;
            bar.setSize(Vector2f((float)23, (float) (-1*numLetters[a]*countHeightRatio)));
            bar.setPosition(Vector2f((float)((23*a)),(float)(640)));
            if ((numLetters[a] * countHeightRatio) > 620) {
                bar.setFillColor(Color::Red);
            }
            else {
                bar.setFillColor(Color::White);
            }
            window.draw(bar);
            
            Text text;
            text.setPosition(Vector2f((float)((23 * a)), (float)(610)));
            text.setString(charToString(a));
            text.setColor(Color::Blue);
            text.setFont(myFont);
            text.setCharacterSize(20);
            window.draw(text);

        }

        

        // Apply all the draws to the screen
        window.display();

        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed)
                window.close();
        }
    }

    return EXIT_SUCCESS;
}

void genFreq(int numLetters[26]) {

    int lineLength;

    char letterPlace;


    string linePlace;

    ifstream alice("alice.txt");


    if (alice.fail()) {
        cerr << "Error opening input file";
        exit(1);
    }

    while (!alice.eof()) {
        getline(alice, linePlace);
        lineLength = linePlace.length();

        for (int i = 0; i < lineLength; ++i) {
            letterPlace = linePlace.at(i);

            switch (letterPlace) {
            case 'a':
            case'A':
                numLetters[0] = numLetters[0] + 1;
                break;
            case 'b':
            case'B':
                numLetters[1] = numLetters[1] + 1;
                break;
            case'c':
            case'C':
                numLetters[2] = numLetters[2] + 1;
                break;
            case 'd':
            case'D':
                numLetters[3] = numLetters[3] + 1;
                break;
            case 'e':
            case'E':
                numLetters[4] = numLetters[4] + 1;
                break;
            case'f':
            case'F':
                numLetters[5] = numLetters[5] + 1;
                break;
            case 'g':
            case'G':
                numLetters[6] = numLetters[6] + 1;
                break;
            case 'h':
            case'H':
                numLetters[7] = numLetters[7] + 1;
                break;
            case'i':
            case'I':
                numLetters[8] = numLetters[8] + 1;
                break;
            case 'j':
            case'J':
                numLetters[9] = numLetters[9] + 1;
                break;
            case 'k':
            case'K':
                numLetters[10] = numLetters[10] + 1;
                break;
            case'l':
            case'L':
                numLetters[11] = numLetters[11] + 1;
                break;
            case 'm':
            case'M':
                numLetters[12] = numLetters[12] + 1;
                break;
            case 'n':
            case'N':
                numLetters[13] = numLetters[13] + 1;
                break;
            case'o':
            case'O':
                numLetters[14] = numLetters[14] + 1;
                break;
            case 'p':
            case'P':
                numLetters[15] = numLetters[15] + 1;
                break;
            case 'q':
            case'Q':
                numLetters[16] = numLetters[16] + 1;
                break;
            case'r':
            case'R':
                numLetters[17] = numLetters[17] + 1;
                break;
            case 's':
            case'S':
                numLetters[18] = numLetters[18] + 1;
                break;
            case 't':
            case'T':
                numLetters[19] = numLetters[19] + 1;
                break;
            case'u':
            case'U':
                numLetters[20] = numLetters[20] + 1;
                break;
            case 'v':
            case'V':
                numLetters[21] = numLetters[21] + 1;
                break;
            case 'w':
            case'W':
                numLetters[22] = numLetters[22] + 1;
                break;
            case'x':
            case'X':
                numLetters[23] = numLetters[23] + 1;
                break;
            case 'y':
            case'Y':
                numLetters[24] = numLetters[24] + 1;
                break;
            case 'z':
            case'Z':
                numLetters[25] = numLetters[25] + 1;
                break;

            }

        }
    }
    alice.close();

    for (int j = 0; j < 26; ++j) {
        cout << numLetters[j] << endl;
    }
    return;

}

string charToString(int a) {
    string place;
    char character = 97;
    character = character + a;
    place = character;
    return place;
    
}
