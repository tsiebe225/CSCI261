#include <iostream>
using namespace std;

#include <SFML/Graphics.hpp>
using namespace sf;

#include<fstream>

int main() {

    int xPos;
    int yPos;
    double brightness;
    int useableBrightness;
    RenderWindow window(VideoMode(640, 640), "SFML Template");

    ifstream starData("ModifiedStars.txt");

    if (starData.fail()) {
        cerr << "Error opening input file";
        exit(1);
    }

    
    while (window.isOpen()) {

        // Erase the screen with black (because space)
        window.clear();

        /***** PLACE YOUR FILE PROCESSING CODE HERE, AND ADD DRAW CALLS *****/

        starData.seekg(0,starData.beg);

        while (!starData.eof()) {
            starData >> xPos;
            starData >> yPos;
            starData >> brightness;
            useableBrightness = (int)((255 * brightness) /8.0);


            CircleShape star;
            star.setPosition(Vector2f(xPos, yPos));
            star.setRadius(2);
            star.setFillColor(Color(useableBrightness, useableBrightness, useableBrightness));

            window.draw(star);
        }

        /***** END OF FILE PROCESSING AND DRAWING	*****/
        starData.close();

        // Apply all the draws to the screen
        window.display();

        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed)
                window.close();
        }
    }

    

    return EXIT_SUCCESS;
}
