/* CSCI 261 LAB05B
* Author: Tanner Siebe
*
* Passing Value By Reference Practice
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <string>
#include <iomanip>



using namespace std;  // For standard namespace 

void GuestBillActual(double x) {
    cout << "Your current tab is $ " <<x<<endl;
    return;

}
void GuestBillAddBurg(double& y) {
    y = y + 4.99;
    cout << "Your current tab is $" << y << endl;
}
void GuestBillAddDrink(double& z) {
    z = z + 1.99;
    cout << "Your current tab is $" << z << endl;
}

int main() {
    cout << fixed;
    cout << setprecision(2);
    double guestBill = 0;

    int resp=1;
    int burgans;
    int softans;

        cout << "Welcome to the restaurant of CSM!" << endl;
        cout << "We offer the follwoing items:" << endl;
        cout << "\t" << "[1] Veggie Hamburger:" << "\t" << "4.99" << endl;
        cout << "\t" << "[2] Soft Drink: " << "\t" << "1.99" << endl;

        while (resp != 0) {
            cout << "Would you like to order? (Press [0] to leave)" << endl;
            cin >> resp;
            if (resp == 0) {
                return 0;
            }
            else if(resp ==1) {
                GuestBillActual(guestBill);
                cout << "If you were to buy a Veggie burger, your tab would become " << guestBill + 4.99 << endl;
                cout << "Would you like to purchase it?([1] = yes, [2] = no)" << endl;
                cin >> burgans;
                if (burgans == 1) {
                    cout << "You've successfully purchased a Veggie Hamburger!" << endl;
                    GuestBillAddBurg(guestBill);
                }
                else{
                    GuestBillActual(guestBill);
                }
            }
            else if (resp == 2) {
                GuestBillActual(guestBill);
                cout << "If you were to buy a soft drink, your tab would become " << guestBill + 1.99 << endl;
                cout << "would you like to purchase it? ([1] = yes, [2] = no)" << endl;
                cin >> softans;
                if (softans == 1) {
                    cout << "You've successfully purchased a soft drink!" << endl;
                    GuestBillAddDrink(guestBill);
                }
                else
                    GuestBillActual(guestBill);
            }
        }

    return 0; // program ended fine 

}
