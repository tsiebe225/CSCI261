/* CSCI 261 LAB05A
* Author:Tanner Siebe
*
* Random number generator
*/

#include <iostream>   // For cin, cout, etc.
using namespace std;  // For standard namespace 



short MyRand(int a) // a is value input, which is theSeed from main
{
    short randGen;
    srand(a);
    randGen = (rand() % 3);
    return randGen;
}

int main() {

    /******** MODIFY OR INSERT CODE BELOW HERE ********/
    int theSeed;
    
    cout << "Enter value for seed:";
    cin>>theSeed;

    cout << MyRand(theSeed)<< endl;

    /******** MODIFY OR INSERT CODE ABOVE HERE ********/

    return 0; // program ended fine 

}