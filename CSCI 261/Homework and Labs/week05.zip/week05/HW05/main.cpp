/* CSCI 261 HW05    
* Author:Tanner Siebe
*
* 
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <string.h>
#include <iomanip>
using namespace std;  // For standard namespace 

void Menu();
void PoundsToKiloGrams();
double DoPoundsToKiloGrams(double);
void FeetToMeters();
double DoFeetToMeters(double);
void BodyMassIndex();
double DoBMI(double, double);
void MilesTokm();
double DoMilesTokm(double);


void Menu() {
    int resp=1;
    while (resp != 0) {
        cout << "What calculation would you like to do?" << endl;
        cout << "Enter 1 for Pounds to Kilograms, 2 for Feet to meters, 3 for Body Mass Index and 4 for Miles to Kilometers." << endl;
        cin >> resp;
        if (resp == 1) {
            PoundsToKiloGrams();
        }
        else if (resp == 2) {
            FeetToMeters();
        }
        else if (resp == 3) {
            BodyMassIndex();
        }
        else if (resp == 4) {
            MilesTokm();
        }
        return;
    }
}

void PoundsToKiloGrams() {
    double inputlbs;
    int resp;
    cout << "Enter value for lbs:" << endl;
    cin >> inputlbs;
    if (inputlbs < 0) {
        cout<<"Are you sure you want a negative number?(1 for yes, 0 for no)" << endl;
        cin >> resp;
        if (resp == 1) {
            inputlbs = inputlbs;
        }
        else {
            inputlbs = -inputlbs;
        }
    }
    cout << inputlbs << " lbs is " << DoPoundsToKiloGrams(inputlbs) << " Kilograms." << endl;
    return;
}

double DoPoundsToKiloGrams(double lbs) {
    return lbs*.454;//set precision to 3 due to given 3 digits
}

void FeetToMeters() {
    double inputFeet;
    int resp;
    cout << "Enter value for feet:" << endl;
    cin >> inputFeet;
    if (inputFeet < 0) {
        cout << "Are you sure you want a negative input?(1 for yes, 0 for no)" << endl;
        cin >> resp;
        if (resp == 1) {
            inputFeet = inputFeet;
        }
        else {
            inputFeet = -inputFeet;
        }
    }
    cout << inputFeet << " feet is " << DoFeetToMeters(inputFeet) << " Meters." << endl;
    return;
}

double DoFeetToMeters(double ft) {
    cout << setprecision(4);//set precision to 4 due to given 4 decimal points
    return ft*.3048;
}
void BodyMassIndex() {
    double inputM;
    double inputkg;
    cout << "Enter values for height and weight in meters and kilograms (Height first, then weight)" << endl;
    cin >> inputM >> inputkg;
    while (inputM <= 0) {
        if (inputM < 0) {
            cout << "Negative height entered, value was changed to positive." << endl;
            inputM = -inputM;
        }
        else if (inputM == 0) {
            cout << "Invalid input, height cannot be zero re enter height:" << endl;
            cin >> inputM;
        }
    }
    while (inputkg <= 0) {
        if (inputkg < 0) {
            inputkg = -inputkg;
            cout << "Negative weight entered, value was made positive." << endl;
        }
        else if (inputkg == 0) {
            cout << "Invalid input, weight cannot be zero re enter weight:" << endl;
            cin >> inputkg;
        }
    }
    cout << "With a height of " << inputM << " and a weight of " << inputkg << " the subject would have a BMI of " << DoBMI(inputM, inputkg) << "." << endl;
    return;
}
double DoBMI(double m, double kg) {
    cout << setprecision(1);//BMI is typically reported to one dec place
    return kg / (m*m);
}
void MilesTokm() {
    double inputMiles;
    int resp;
    cout << "Enter value for miles:" << endl;
    cin >> inputMiles;
    if (inputMiles < 0) {
        cout << "Are you sure you want a negative mile input?(1 for yes, 0 for no)" << endl;
        cin>>resp;
        if (resp == 1) {
            inputMiles = inputMiles;
        }
        else {
            inputMiles = -inputMiles;
        }
    }
    cout << inputMiles << " miles is " << DoMilesTokm(inputMiles) << " Kilometers." << endl;
    return;
}
double DoMilesTokm(double miles) {
    return miles*1.609;//left to 3 precision
}
int main() {
    // DO NOT change this main function 
    cout << fixed;
    cout << setprecision(3);

    Menu();

    return 0;

} // end of Main Function
