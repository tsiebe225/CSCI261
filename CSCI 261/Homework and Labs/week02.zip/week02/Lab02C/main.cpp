/* CSCI 261 LAB02C ASCII Fun
* Author: Tanner Siebe (_INSERT_YOUR_NAME_HERE_)
*
* Change input to yelling
*/

#include <iostream>   // For cin, cout, etc.
using namespace std;  // For standard namespace 

int main() {

    /******** MODIFY OR INSERT CODE BELOW HERE ********/

    char characterOne;
    char characterTwo;
    char characterThree;
    char characterFour;
    char characterFive;

    cout << "Input Character One" << endl;
    cin >> characterOne;
    cout << "Input Character Two" << endl;
    cin >> characterTwo;
    cout << "Input Character Three" << endl;
    cin >> characterThree;
    cout << "Input Character Four" << endl;
    cin >> characterFour;
    cout << "Input Character Five" << endl;
    cin >> characterFive;
    cout << '\n';


    characterOne = characterOne - 32;
    characterTwo = characterTwo - 32;
    characterThree = characterThree - 32;
    characterFour = characterFour - 32;
    characterFive = characterFive - 32;

    cout << characterOne << endl;
    cout << characterTwo << endl;
    cout << characterThree << endl;
    cout << characterFour << endl;
    cout << characterFive << endl;

    cout << "Why are you yelling???" << endl;
    cout << '\n';

    /******** MODIFY OR INSERT CODE ABOVE HERE ********/

    return 0; // program ended fine 

}