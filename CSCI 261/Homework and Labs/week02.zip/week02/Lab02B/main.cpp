/* CSCI 261 LABXXX_OR_HWYYY: NAME_OF_ASSIGNMENT
* Author: Tanner Siebe (_INSERT_YOUR_NAME_HERE_)
*
* circle area calculation
*/

#include <iostream>   // For cin, cout, etc.
using namespace std;  // For standard namespace 

int main() {

    /******** MODIFY OR INSERT CODE BELOW HERE ********/


    double circleRadius = 0.0;
    double circleArea = 0.0;
    const double valPI = 3.14159;


    cout << "Ready to code!!" << endl;

    cout << "What is the circle's radius" << endl;
    cin >> circleRadius;


    circleArea = circleRadius * circleRadius * valPI;

    cout << "The area of the circle with radius " << circleRadius << " is " << circleArea << "." << endl;


    /******** MODIFY OR INSERT CODE ABOVE HERE ********/


    return 0; // program ended fine 

}