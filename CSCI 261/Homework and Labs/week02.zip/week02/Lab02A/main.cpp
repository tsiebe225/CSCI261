/* CSCI 261 Lab 02A: PRISM VOLUME
*
* Author: Tanner Siebe (_INSERT_YOUR_NAME_HERE_)
*
* Finding the volume of a prism with given inputs
*/

// The include section adds extra definitions from the C++ standard library.
#include <iostream> // For cin, cout, etc.

// We will (most of the time) use the standard library namespace in our programs.
using namespace std;

// Must have a function named "main", which is the starting point of a C++ program.
int main() {


    int length = 17;
    int width = 17;
    int height = 2;
    int volume = 0;

    cout << "What is the body's length?"<<endl;
    cin >> length;
    cout << "What is the body's width?"<<endl;
    cin >> width;
    cout << "What is the body's height?"<<endl;
    cin >> height;
    
    // Volume of a box is length times width times height. 
    volume = length * width * height;


    cout << "The prism's volume is " << volume<<endl;

    return 0; // signals the operating system that our program ended OK.

}