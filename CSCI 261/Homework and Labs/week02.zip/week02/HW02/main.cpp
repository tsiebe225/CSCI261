/* CSCI 261 HW02: Arithmetic, Cars, and Triangles
* Author: Tanner Siebe
*
* Basic math, working with functions 
*/

#include <iostream>// For cin, cout, etc.
#include <iomanip>
#include <cmath>
using namespace std;  // For standard namespace 

int main() {
    // PART I: INSERT YOUR CODE BELOW HERE
    
    cout << fixed;
    cout << setprecision(2);

    int x = 0;
    int y = 0;
    int z = 0;

    cout << "Input value for x:";
    cin >> x;
    cout << "Input value for y:";
    cin >> y;
    cout << "Input value for z:";
    cin >> z;
    cout << "The values for x,y and z are " << x << ", " << y << " and " << z << " respectively." << endl;
    
    cout << "The value of x + y is " << x + y << "." << endl;
    cout << "The value of (x + y * z) is " << x + y*z << "." << endl;
    cout << "The value of (x + y) * z)) is " << ((x + y)*z) << "." << endl; //This differs from the part above due to order of operations, the additon comes first in this sequence
    cout << "The value of x / y is " << x / y << ". This may be wrong, it is due to how the variables are   defined in the code, but it can corrected as shown below." << endl;
    cout << "The value of x % y is " << x%y << ". This function states the remainder." << endl;
    cout << "The value of x / y is " << static_cast<double>(x)/static_cast<double>(y) << "." << endl;
    cout << "The value of (x^2 + 2y - 6xz) is " << pow(x, 2) + (2 * y) - (6 * x*z) << "." << endl;


    // PART I INSERT YOUR CODE ABOVE HERE
    // PART II: INSERT YOUR CODE BELOW HERE

    double timeToSixtyOne;
    double timeToSixtyTwo;
    double accelOne;
    double accelTwo;
    
    cout << endl;

    cout << "Part 2 starting below" << endl;
    cout <<endl;
    
    cout << "What is the time (in seconds) it takes to reach 60 mph for vehicle one?" << endl;
    cin >> timeToSixtyOne;
    cout << "What is the time (in seconds) it takes to reach 60 mph for vehicle two??" << endl;
    cin >> timeToSixtyTwo;

    accelOne = (88)/timeToSixtyOne ;
    accelTwo = (88)/timeToSixtyTwo;

    cout << "The acceleration of vehicle one is " << accelOne << " feet per s^2 and the acceleration is " << accelTwo << " feet per s^2." << endl;
    cout << "The ratio of car one's acceleration to car two's acceleration is " << accelOne / accelTwo << "." << endl;

    // PART II INSERT YOUR CODE ABOVE HERE
    // PART III INSERT YOUR CODE BELOW HERE

    cout << endl;
    cout << "Part 3 starting below" << endl;
    cout <<endl;
    
    double xCoorOne;
    double yCoorOne;
    double xCoorTwo;
    double yCoorTwo;
    double xCoorThree;
    double yCoorThree;
    double sideOne;
    double sideTwo;
    double sideThree;
    double trianglePerimeter;
    double triangleArea;
    double halfPerimeter;

    cout << "Enter coordinates for the first point:";
    cin >> xCoorOne >> yCoorOne;
    cout << "Enter coordinates for the second point:";
    cin >> xCoorTwo >> yCoorTwo;
    cout << "Enter coordinates for the third point:";
    cin >> xCoorThree >> yCoorThree;

    sideOne = sqrt((pow((xCoorOne - xCoorTwo), 2) + pow((yCoorOne - yCoorTwo), 2)));
    sideTwo = sqrt((pow((xCoorTwo - xCoorThree), 2) + pow((yCoorTwo - yCoorThree), 2)));
    sideThree = sqrt((pow((xCoorThree - xCoorOne), 2) + pow((yCoorThree - yCoorOne), 2)));
  
    cout << "Sides of the triangle are " << sideOne << ", " << sideTwo << " and " << sideThree << "." << endl;

    trianglePerimeter = sideOne + sideTwo + sideThree;

    cout << "Perimeter of the triangle is " << trianglePerimeter << "." << endl;

    halfPerimeter = trianglePerimeter / 2;
    
    triangleArea = sqrt(halfPerimeter*(halfPerimeter - sideOne)*(halfPerimeter - sideTwo)*(halfPerimeter - sideThree));

    cout << "Area of the triangle is " << triangleArea << "." << endl;

   


  




    // PART III INSERT YOUR CODE ABOVE HERE

    return 0; // signals the operating system that our program ended OK.
}