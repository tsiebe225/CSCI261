/* CSCI 261 HW04
* Author:Tanner Siebe
*
* Add more complete description here...
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <iomanip>
#include <ctime>


using namespace std;  // For standard namespace 

int main() {

    /******** MODIFY OR INSERT CODE BELOW HERE ********/
    
    const int tooLow = 0;
    const int tooHigh = 100;
    const int tooCLoseDiff = 2;
    const int tooFarDiff = 20;
    int compGen;
    int personGuess=0;
    int numGuesses = 0;

    srand(time(0));

    compGen = (rand() % 101);

    cout << "Hold onto your pants, we're about to play guess-the-numbah!" << endl;

    while (compGen != personGuess) {
        cout << "Pick a number between 0 and 100:" << endl;
        cin >> personGuess;
        numGuesses = numGuesses + 1;

        if (personGuess == compGen) {
            cout << "Thats' right! You won the game in " << numGuesses << " tries!" << endl;
        }
        else if((personGuess>100)||(personGuess<0)){
            cout << "Please enter number in valid range." << endl;
            numGuesses = numGuesses - 1;
        }
        else if (abs(compGen - personGuess) >= 20) {
            if (compGen > personGuess) {
                cout << "Too low, not even close!" << endl;
            }
            else {
                cout << "Too high, not even close!" << endl;
            }
        }
        else if ((abs(personGuess - compGen)) <= 2) {
            if (personGuess < compGen) {
                cout << "Too low! Ohh you're close!" << endl;
            }
            else {
                cout << "Too high! Ohh you're close!" << endl;
            }
        }
           
        else {
            if (personGuess > compGen) {
                cout << "Too high, try again" << endl;
            }
            else {
                cout << "Too low, try again" << endl;
            }
        }
    }
    


    /******** MODIFY OR INSERT CODE ABOVE HERE ********/

    return 0; // program ended fine 

}