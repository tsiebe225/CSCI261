/* CSCI 261 LAB04A 
* Author:Tanner Siebe   
*
* While loop practicing
*/

#include <iostream>   // For cin, cout, etc.
#include <cmath>
#include <iomanip>

using namespace std;  // For standard namespace 


int main() {

    /******** MODIFY OR INSERT CODE BELOW HERE ********/
    cout << fixed;
    cout << setprecision(2);

    double sideOne=0;
    double sideTwo=0;
    double sideThree=0;
    bool isTriangle = false;

  

    while (isTriangle != true) {
        cout << "Input the side lengths" << endl;
        cin >> sideOne >> sideTwo >> sideThree;

        if ((sideOne <= 0) || (sideTwo <= 0) || (sideThree <= 0)) {
            cout << "Invalid input, input cannot be less than or equal to zero." << endl;
        }
        else if ((sideOne + sideTwo > sideThree) && (sideTwo + sideThree > sideOne) && (sideOne + sideThree > sideTwo)) {
            cout << "Woohoo - input is valid" << endl;
            isTriangle = true;
        }
        else if ((sideOne + sideTwo < sideThree) || (sideTwo + sideThree < sideOne) || (sideOne + sideThree < sideTwo)) {
            cout << "Invalid input, does not form triangle." << endl;
        }

    }

   

    /******** MODIFY OR INSERT CODE ABOVE HERE ********/

    return 0; // program ended fine 

}