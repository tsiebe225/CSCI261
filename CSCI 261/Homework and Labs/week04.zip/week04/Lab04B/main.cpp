/* CSCI 261 LABXXX_OR_HWYYY: NAME_OF_ASSIGNMENT
* Author: XXXX (_INSERT_YOUR_NAME_HERE_)
*
* Add more complete description here...
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
using namespace std;  // For standard namespace 

int main() {

    /******** MODIFY OR INSERT CODE BELOW HERE ********/
    int numBottles;

    cout << "Hello, I'd like to sing you a song." << endl;

    cout << "Enter a number:";
    cin >> numBottles;

    while (numBottles >= 3) {
        cout << numBottles << " bottles of hand sanitizer on the wall," << endl;
        cout << numBottles << " bottles of hand sanitizer!" << endl;
        cout << "Take 1 down, pass it around," << endl;

        numBottles = numBottles - 1;
        cout << numBottles << " bottles of hand sanitizer on the wall!" << endl;
        cout << endl;

    }
    if (numBottles<3)
    cout << " 2 bottles of hand sanitizer on the wall" << endl;
    cout << "2 bottles of hand sanitizer!" << endl;
    cout << "Take 1 down, pass it around."<<endl;
    cout << "1 bottle of hand sanitizer on the wall!"<<endl;
    cout << endl;

    cout << "1 bottle of hand sanitizer on the wall," << endl;
    cout << "1 bottle of hand sanitizer!" << endl;
    cout << "Take 1 down, pass it around," << endl;
    cout << "0 bottles of hand saniter on the wall!" << endl;

    /******** MODIFY OR INSERT CODE ABOVE HERE ********/

    return 0; // program ended fine 

}
