/* CSCI261 HW07: Smart Blackjack
*
*     Author: jpaone
* Created on: 11 Feb 2016
*
* This program plays Blackjack in a naive manner.  Only cards
* with values 1-10 are available and cards are randomly
* generated.  There is no enforcement that a card cannot be dealt
* twice in a row to the Player or Dealer.
*/

#include <cstdlib>		// for srand(), rand()
#include <ctime>		// for time()

#include <iostream>		// for cout, cin, etc.
#include <string>		// for string
using namespace std;

/*
* The structure of our Card data type.
* Contains the rank of the card as an int
* and the suit of the card as a string.
*/
struct Card {
    int rank;			// rank of card, expected acceptable values 1-10
    string suit;		// suit of card, expected values "Hearts", "Clubs", "Diamonds", "Spades"
};


void ShuffleDeck(Card[52]);
Card GetNextCard(Card[52],int&);




/*
* Prints a Card variable to the terminal in the
* format of "<rank> of <suit>"
*
* Input:
* 		Card card : the card to display
*
* Output:
*
*/
void PrintCard(const Card card);

/*
* Updates the total by adding the rank of the
* card.
*
* Input:
* 		int total : the total to update
* 		Card card : the card to add to the total
*
* Output:
*
*/
void UpdateTotal(int &total, const Card card);

/*
* The main function of our program.  This is the entry
* point to our program and will be run first.
*
* Input:
*
* Output:
* 		int exitCode : code returned when program exits
*/
int main() {
    int index = 0;

    Card deck[52];
    deck[0].rank = 11;
    deck[0].suit = "Ace of Hearts";
    deck[1].rank = 2;
    deck[1].suit = "Two of Hearts";
    deck[2].rank = 3;
    deck[2].suit = "Three of Hearts";
    deck[3].rank = 4;
    deck[3].suit = "Four of Hearts";
    deck[4].rank = 5;
    deck[4].suit = "Five of Hearts";
    deck[5].rank = 6;
    deck[5].suit = "Six of Hearts";
    deck[6].rank = 7;
    deck[6].suit = "Seven of Hearts";
    deck[7].rank = 8;
    deck[7].suit = "Eight of Hearts";
    deck[8].rank = 9;
    deck[8].suit = "Nine of Hearts";
    deck[9].rank = 10;
    deck[9].suit = "Ten of Hearts";
    deck[10].rank = 10;
    deck[10].suit = "Jack of Hearts";
    deck[11].rank = 10;
    deck[11].suit = "Queen of Hearts";
    deck[12].rank = 10;
    deck[12].suit = "King of Hearts";
    deck[13].rank = 11;
    deck[13].suit = "Ace of Diamonds";
    deck[14].rank = 2;
    deck[14].suit = "Two of Diamonds";
    deck[15].rank = 3;
    deck[15].suit = "Three of Diamonds";
    deck[16].rank = 4;
    deck[16].suit = "Four of Diamonds";
    deck[17].rank = 5;
    deck[17].suit = "Five of Diamonds";
    deck[18].rank = 6;
    deck[18].suit = "Six of Diamonds";
    deck[19].rank = 7;
    deck[19].suit = "Seven of Diamonds";
    deck[20].rank = 8;
    deck[20].suit = "Eight of Diamonds";
    deck[21].rank = 9;
    deck[21].suit = "Nine of Diamonds";
    deck[22].rank = 10;
    deck[22].suit = "Ten of Diamonds";
    deck[23].rank = 10;
    deck[23].suit = "Jack of Diamonds";
    deck[24].rank = 10;
    deck[24].suit = "Queen of Diamonds";
    deck[25].rank = 10;
    deck[25].suit = "King of Diamonds";
    deck[26].rank = 11;
    deck[26].suit = "Ace of Clubs";
    deck[27].rank = 2;
    deck[27].suit = "Two of Clubs";
    deck[28].rank = 3;
    deck[28].suit = "Three of Clubs";
    deck[29].rank = 4;
    deck[29].suit = "Four of Clubs";
    deck[30].rank = 5;
    deck[30].suit = "Five of Clubs";
    deck[31].rank = 6;
    deck[31].suit = "Six of Clubs";
    deck[32].rank = 7;
    deck[32].suit = "Seven of Clubs";
    deck[33].rank = 8;
    deck[33].suit = "Eight of Clubs";
    deck[34].rank = 9;
    deck[34].suit = "Nine of Clubs";
    deck[35].rank = 10;
    deck[35].suit = "Ten of Clubs";
    deck[36].rank = 10;
    deck[36].suit = "Jack of Clubs";
    deck[37].rank = 10;
    deck[37].suit = "Queen of Clubs";
    deck[38].rank = 10;
    deck[38].suit = "King of Clubs";
    deck[39].rank = 11;
    deck[39].suit = "Ace of Spades";
    deck[40].rank = 2;
    deck[40].suit = "Two of Spades";
    deck[41].rank = 3;
    deck[41].suit = "Three of Spades";
    deck[42].rank = 4;
    deck[42].suit = "Four of Spades";
    deck[43].rank = 5;
    deck[43].suit = "Five of Spades";
    deck[44].rank = 6;
    deck[44].suit = "Six of Spades";
    deck[45].rank = 7;
    deck[45].suit = "Seven of Spades";
    deck[46].rank = 8;
    deck[46].suit = "Eight of Spades";
    deck[47].rank = 9;
    deck[47].suit = "Nine of Spades";
    deck[48].rank = 10;
    deck[48].suit = "Ten of Spades";
    deck[49].rank = 10;
    deck[49].suit = "Jack of Spades";
    deck[50].rank = 10;
    deck[50].suit = "Queen of Spades";
    deck[51].rank = 10;
    deck[51].suit = "King of Spades";

    ShuffleDeck(deck);



    srand(time(NULL));											// seed our RNG with the current time

    bool keepPlaying = true;										// keeps track if the user wants to continue playing

    while (keepPlaying) {											// as long as the user decides to keep playing

                                                                    // Step 0
                                                                    // set up our variables to be used this hand
        string userChoice;											// keeps track of the entered user's choice
        int userTotal = 0, dealerTotal = 0;							// the card total for the user and dealer this hand
        int playerRunningTot=22;
                                                                    // Step 1
                                                                    // Deal a card to the Dealer
        Card recentCard = GetNextCard(deck,index);							// generate a random card for the dealer
        cout << "Dealer shows the ";
        PrintCard(recentCard);
        cout << endl;
        UpdateTotal(dealerTotal, recentCard);						// add the card's rank to the dealer's total
        cout << "Dealer total is: " << dealerTotal << endl;

        // Step 2
        // Deal a card to the User
        recentCard = GetNextCard(deck,index);								// generate a random card for the user
        cout << "You were dealt the ";
        PrintCard(recentCard);
        cout << endl;
        UpdateTotal(userTotal, recentCard);						// add the card's rank to the user total

        do {
            // Step 3
            // Deal another card to the user
            recentCard = GetNextCard(deck,index);							// generate a random card for the user
            cout << "You were dealt the ";
            PrintCard(recentCard);
                cout << endl;
                UpdateTotal(userTotal, recentCard);					// add the card's rank to the user total
                cout << "Your total is: " << userTotal << endl;
            

            if ((userTotal > 21)) {									// if the user total is above 21
                cout << "You busted! ";								// tell the user they busted
                break;												// break out of the loop
            }

            cout << "Do you want to \"Hit\", \"Stand\"?\n> ";		// ask the user if they want another card
            cin >> userChoice;
        } while (userChoice.compare("Stand") != 0);				// only stop dealing cards to the user if they
                                                                // type stand.  Otherwise, deal them another card

                                                                // Step 4
                                                                // Deal another card to the Dealer if user didn't bust
        if (userTotal <= 21) {										// check that user did not bust
            while (dealerTotal < 17) {								// while the Dealer has less than 17 points
                recentCard = GetNextCard(deck,index);						// generate a random card to the Dealer
                cout << "Dealer was dealt the ";
                PrintCard(recentCard);
                cout << endl;
                UpdateTotal(dealerTotal, recentCard);				// add the card's rank to the user total
                cout << "Dealer total is: " << dealerTotal << endl;
            }
        }

        // Step 5
        // Print winner
        if (userTotal > 21) {										// if user busted
            cout << "Dealer wins" << endl;								// then Dealer wins
        }
        else if (dealerTotal > 21) {								// otherwise if Dealer busted
            cout << "Dealer busted!  You win" << endl;					// then user wins
        }
        else if (dealerTotal > userTotal) {						// otherwise, nobody busted, Dealer's total is higher
            cout << "Dealer wins" << endl;								// then Dealer wins
        }
        else if (userTotal > dealerTotal) {						// otherwise if user's total is higher
            cout << "You win" << endl;									// then user wins
        }
        else {													// otherwise, nobody's total is higher
            cout << "Push" << endl;										// hand is a push
        }

        // Step 6
        // Ask user if they want to play again
        cout << "Do you want to play again?  \"Yes\" or \"No\"?\n> ";
        cin >> userChoice;

        if (userChoice.compare("No") == 0) {						// if user says No
            keepPlaying = false;										// then turn on keep playing flag off
        }
    }

    return EXIT_SUCCESS;											// report the program exited successfully
}

void PrintCard(const Card card) {
    cout << card.suit;
}

void UpdateTotal(int &total, const Card card) {
    total += card.rank;												// add the rank of the card to the total
}

void ShuffleDeck(Card deck[52]) {
    string p1;
    string p2;
    int p3;
    int p4;
    int j;
    srand(time(NULL));
    for (int i = 0; i < 52; ++i) {
        j = (rand() % 52);
        p1 = deck[j].suit;
        p3 = deck[j].rank;
        p2 = deck[i].suit;
        p4 = deck[i].rank;
        deck[j].suit = p2;
        deck[i].suit = p1;
        deck[j].rank = p4;
        deck[i].rank = p3;
    }
}

Card GetNextCard(Card deck[52], int& index) {
    index = index + 1;
    if (index > 32) {
        ShuffleDeck(deck);
        index = 0;
    }
    return deck[index];
}