/* CSCI 261 HW05
* Author:Tanner Siebe
*
*
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <string.h>
#include <iomanip>
using namespace std;  // For standard namespace 

const int NROWS = 4;
const int NCOLS = 2;

void AssignRow(int mat[NROWS][NCOLS]);
void PrintMatrixOrg(int matOrg[NROWS][NCOLS]);
void PrintMatrixTrans(int matTrans[NCOLS][NROWS]);
void TransposeMatrix(int matOrg[NROWS][NCOLS], int matTrans[NCOLS][NROWS]);

int main() {
    int matrixOrg[NROWS][NCOLS];
    int matrixTrans[NCOLS][NROWS];

    AssignRow(matrixOrg);
    PrintMatrixOrg(matrixOrg);
    TransposeMatrix(matrixOrg, matrixTrans);
    PrintMatrixTrans(matrixTrans);


    return 0;

}

void AssignRow(int mat[NROWS][NCOLS]) {
    int i;
    int j;
    int value;
    for (i = 0; i < NROWS; ++i) {
        cout << "Enter entries for row " << i << ": ";
        for (j = 0; j < NCOLS;++j){
            cin >> value;
            mat[i][j] = value;
        }
    }
    return;
}

void PrintMatrixOrg(int matrix[NROWS][NCOLS]) {
    for (int i = 0; i < NROWS; ++i) {
        for (int j = 0; j < NCOLS; ++j) {
            cout << matrix[i][j]<<"  ";
        }
        cout << endl;
    }
    return;
}

void TransposeMatrix(int matrixOrg[NROWS][NCOLS], int matrixTrans[NCOLS][NROWS]) {
    int value;
    for (int i = 0; i < NROWS; ++i) {
        for (int j = 0; j < NCOLS; ++j) {
            value = matrixOrg[i][j];
            matrixTrans[j][i]=value;
        }
    }
}

void PrintMatrixTrans(int matrixTrans[NCOLS][NROWS]) {
    for (int i = 0; i < NCOLS; ++i) {
        for (int j = 0; j < NROWS; ++j) {
            cout << matrixTrans[i][j]<< "  ";
        }
        cout << endl;
    }
}