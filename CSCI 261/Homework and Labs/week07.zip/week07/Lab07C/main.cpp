/* CSCI 261:
* Author: Tanner Siebe
*
*
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <string>
#include <iomanip>

using namespace std;  // For standard namespace 

int main() {
    int hold[5];
    int i;
    int j;
    int largest;
    int spotInArray;
    cout << "Hey!Witness my first array mojo!" << endl;
    cout << "Enter 5 numbers and I will tell you which is the largest." << endl;
    for (i = 0; i <= 4; ++i) {
        cout << "Number " << i + 1 << ": ";
        cin >> hold[i];
    }
    largest = hold[0];
    spotInArray = 0;
    for (j = 1; j <= 4; ++j) {
        if (largest < hold[j]) {
            largest = hold[j];
            spotInArray = j;
        }
    }
    cout << "The largest value in the array is " << largest << " enter as number  "<<spotInArray+1<<" in the array.";

    return 0;

}