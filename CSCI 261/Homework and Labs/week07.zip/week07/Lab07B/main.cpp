/* CSCI 261 HW05
* Author:Tanner Siebe
*
*
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <string>
#include <iomanip>
using namespace std;  // For standard namespace 

struct Measurement {
    int miles;
    long meters;
};
struct Destination {
    string city;
    Measurement distance;
};

void PrintDest(const Destination& dest);


int main() {
    Destination destination1;
    destination1.city = "Tupelo";
    destination1.distance.miles = 375;
    destination1.distance.meters = 603375;
    const Destination destAct = destination1;
    PrintDest(destAct);



    return 0; // program ended fine 

}

void PrintDest(const Destination& destPlace) {
    cout << destPlace.city << endl;
    cout << destPlace.distance.miles << endl;
    cout << destPlace.distance.meters << endl;
    return;
}

