/* CSCI 261:
* Author: Tanner Siebe
*
*
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <string>
#include <iomanip>

using namespace std;  // For standard namespace 

double RectArea(double length, double width);
double DiameterInput();
void DivideByTwo(double& one, double& two, double&three);
int NumVowels(const string& string1);


int main() {
    double recLength = 0;
    double recWidth = 0;
    double numOne;
    double numTwo;
    double numThree;
    string placeholder;

    cout << "Enter dimensions rectangle area" << endl;
    cout << "Width:";
    cin >> recWidth;
    cout << "Length:";
    cin >> recLength;

    cout << RectArea(recLength, recWidth) << " is the area of the rectangle." << endl;

    cout << "\n";

    DiameterInput();

    cout << "Each of the following will be divided by two" << endl;
    cout<<"Input the three numbers you'd like to divide by two" << endl;
    cin >> numOne >> numTwo >> numThree;
    DivideByTwo(numOne, numTwo, numThree);
    cout << "Your results for dividing by 2 are " << numOne << ", " << numTwo << " and " << numThree << " respectivley." << endl;

    cout << "Enter the string you would like to know how many vowels are in:";
    cin >> placeholder;
    const string userImpStrng = placeholder;
    cout << userImpStrng << " has " << NumVowels(userImpStrng) << " vowels." << endl;
    



    return 0; // program ended fine 

}


double RectArea(double length, double width) {
    return (length*width);
}

double DiameterInput() {
    double userInp;
    cout << "Hello! Here is your joke of the day:" << endl;
    cout << "\n";
    cout << "\n";
    cout << "What do you get if you divide hte circumference of a pumpkin by its diameter?" << endl;
    cout << "Pumpkin pi of course. Yum" << endl;//I died a little typing that
    cout << "Please enter your pumpkin's diamter:";
    cin >> userInp;
    return userInp;
}

void DivideByTwo(double& one, double& two, double& three) {
    one = one / 2;
    two = two / 2;
    three =three / 2;
    return;
}
int NumVowels(const string& string) {//fixME
    int counter = 0;
    int i = 0;
    while (i < string.length()) {
        if ((string.at(i) == ('a'))|| (string.at(i) == ('e'))|| (string.at(i) == ('i'))|| (string.at(i) == ('o'))|| (string.at(i) == ('u'))) {
            counter = counter + 1;
            i = i + 1;
        }
        else {
            i = i + 1;
        }
    }
    return counter;
}