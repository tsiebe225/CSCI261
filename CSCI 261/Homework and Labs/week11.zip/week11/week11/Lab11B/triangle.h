#pragma once

class Triangle
{
public:
    Triangle();
    Triangle(double sideOne, double sideTwo, double sideThree);

    double GetSideOne();
    double GetSideTwo();
    double GetSideThree();

    void SetSideOne(double sideOneInput);
    void SetSideTwo(double sideTwoInput);
    void SetSideThree(double sideThreeInput);

    bool TrianglePossible();
    double TriangleArea();
    double TrianglePerimeter();
    bool TriangleComparison(Triangle triOne);

private:
    double sideOne;
    double sideTwo;
    double sideThree;

};

