#include "triangle.h"
#include <math.h>

Triangle::Triangle(){
    sideOne = 1;
    sideTwo = 1;
    sideThree = 1;
}
Triangle::Triangle(double sideOneInput, double sideTwoInput, double sideThreeInput) {
    sideOne = sideOneInput;
    sideTwo = sideTwoInput;
    sideThree = sideThreeInput;
}
double Triangle::GetSideOne() {
    return sideOne;
}
double Triangle::GetSideTwo() {
    return sideTwo;
}
double Triangle::GetSideThree() {
    return sideThree;
}
void Triangle::SetSideOne(double sideOneInput) {
    sideOne = sideOneInput;
    return;
}
void Triangle::SetSideTwo(double sideTwoInput) {
    sideTwo = sideTwoInput;
    return;
}
void Triangle::SetSideThree(double sideThreeInput) {
    sideThree = sideThreeInput;
    return;
}
bool Triangle::TrianglePossible() {
    if (((sideOne + sideTwo) > sideThree) && ((sideOne + sideThree) > sideTwo) && ((sideTwo + sideThree) > sideOne)) {
        return true;
    }
    else {
        return false;
    }
}

double Triangle::TrianglePerimeter() {
    return (sideOne + sideTwo + sideThree);
}

double Triangle::TriangleArea() {
    double place = TrianglePerimeter()/2;
    double x =place*(place - sideOne)*(place - sideTwo)*(place - sideThree);
    x = sqrt(x);
    return x;

}
bool Triangle::TriangleComparison(Triangle triEx) {
    bool x;
    if ((TriangleArea()) > triEx.TriangleArea()) {
        x= true;
    }
    else {
        x=false;
    }
    return x;

}