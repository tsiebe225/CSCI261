//Lab11B
//Tanner Siebe
#include<iostream>
#include"triangle.h"

using namespace std;

int main() {
    Triangle triOne;
    cout << triOne.GetSideOne() << endl;
    cout << triOne.GetSideTwo() << endl;
    cout << triOne.GetSideThree() << endl;

    cout << triOne.TrianglePossible() << endl;
    cout << triOne.TrianglePerimeter() << endl;
    cout << triOne.TriangleArea() << endl;
    cout << triOne.TriangleComparison(triOne) << endl;
    

    triOne.SetSideOne(3);
    triOne.SetSideTwo(4);
    triOne.SetSideThree(5);

    cout << triOne.GetSideOne() << endl;
    cout << triOne.GetSideTwo() << endl;
    cout << triOne.GetSideThree() << endl;

    cout << triOne.TrianglePossible() << endl;
    cout << triOne.TrianglePerimeter() << endl;
    cout << triOne.TriangleArea() << endl;
    cout << triOne.TriangleComparison(triOne) << endl;

    Triangle triLoaded(6, 8, 10);

    cout << triLoaded.GetSideOne() << endl;
    cout << triLoaded.GetSideTwo() << endl;
    cout << triLoaded.GetSideThree() << endl;

    cout << triLoaded.TrianglePossible() << endl;
    cout << triLoaded.TrianglePerimeter() << endl;
    cout << triLoaded.TriangleArea() << endl;
    cout << triLoaded.TriangleComparison(triOne) << endl;


    return 0;
}