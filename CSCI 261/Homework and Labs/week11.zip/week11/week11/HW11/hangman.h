//CSCI261 Section C
//Tanner Siebe


#pragma 
#include<string>
#include<math.h>

using namespace std;

class Hangman{
public:
    Hangman();


    char userGuess;

    void Intro();
    void ShowWord();
    void GetLetter();
    void Gift();

    bool Finished();

    bool FirstLetterCorrect;
    bool SecondLeterCorrect;
    bool ThirdletterCorrect;
    bool FourthLeterCorrect;
    bool FifthLetterCorrect;
    bool SixthLeterCorrect;
    bool SeventhLetterCorrect;
    bool EightLeterCorrect;
    bool NinthLetterCorrect;
    bool TenthLeterCorrect;
    

private:
    char firstLetter;
    char secondLeter;
    char thirdLetter;
    char fourthLetter;
    char fifthLetter;
    char sixthLeter;
    char seventhLetter;
    char eightLeter;
    char ninthLetter;
    char tenthLetter;
};

