
/*
CSC261: Section F
Author: Hayley Lansing
*/

#pragma once

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>

using namespace std;


class Flashcard
{

private:
    int a, b, user_answer, computed_answer, win_count, game_number, num_problems, level_difficulty, prize;
    bool user_right, win, time_start;
    void Introduction();


public:
    Flashcard();
    Flashcard(int num_problems);
    int choose_difficulty();
    void problem_setup();
    void set_numbers();
    void add();
    void subtract();
    void multiply();
    bool correctAnswer();
    bool userWins();
    int getPrize();
    void setPrize();

};
