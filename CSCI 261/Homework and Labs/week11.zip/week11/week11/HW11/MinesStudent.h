
/* Daniel Scarbrough
Section C

Mines Student Class
*/

#pragma once

#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;


class MinesStudent {
public: //public member functions
    int LuckAdjust();
    void Introduction();
    void DrinkCoffee();
    void Study();
    void Register();
    void Party();
    void PartyHard();
    void Sleep();
    void GoToClass();
    void Cry();
    void PrintWeekMenu();
    void WeekChoice(int number);
    void PrintWeekendMenu();
    void WeekendChoice(int number);
    void CheckStatus();
    void StartWeek();
    void StartWeekend();
    void PrintPrize();
    MinesStudent();
private: //private data members
    int hourChoice;
    int menuChoice;
    int sadness;
    int knowledge;
    int dumbLuck;
    int tiredness;
    int timeLeft;
    int classHoursLeft;
    int classHours;
    bool graduated;
    bool isSad;
    bool pregnancy;
    bool isWeekend;
};