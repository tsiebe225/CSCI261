/* CSCI261 HW 11: Class Fun
*
* Description: Implementation file for Slot Machine Class
*
* Author: Derek Hart
*
* This file defines the constructors and functions prototyped in the
* SlotMachine.h file.
*/

#include "SlotMachine.h"
#include <iostream>
#include <time.h>
#include <string>

using namespace std;

//Define default constructor. Note that initial slot values are different
SlotMachine::SlotMachine() {
    prize = "amount of money smaller than what you had originally";
    slotVals[0] = 1;
    slotVals[1] = 2;
    slotVals[2] = 3;
    Introduction();
}

//Introduce the user by explaining to them the rules
void SlotMachine::Introduction() {
    cout << "Welcome to the slot machine, a magical place where statistics don't matter!" << endl << endl;
    cout << "This machine has 3 slots, each of which can take values 1, 2 or 3." << endl;
    cout << "To win a prize, all of the slots must have the same number!" << endl << endl;
}

//Define simple function to present user with prise
string SlotMachine::GetPrize() {
    return prize;
}

//Use for loop to generate values for each index of the array
void SlotMachine::PullLever() {
    for (int i = 0; i < 3; i++) {
        slotVals[i] = ((rand() % 3) + 1);
    }
}

//Display slot values using for loop
void SlotMachine::DisplaySlot() {
    cout << "Your slots show: " << endl;
    for (int i = 0; i < 3; i++) {
        cout << slotVals[i] << " ";
    }
    cout << endl;
}

//Check if the slot values match, return true if they match
bool SlotMachine::CheckSlot() {
    if (
        slotVals[0] == slotVals[1] &&
        slotVals[0] == slotVals[2] &&
        slotVals[1] == slotVals[2]
        )
    {
        return true;
    }
    else
        return false;
}