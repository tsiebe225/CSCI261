/*
CSC261: Section F
Author: Hayley Lansing
*/

#include "Flashcard.h"

// -----------------Constructors-------------------------------
Flashcard::Flashcard()
{
    Introduction();
}

Flashcard::Flashcard(int num_problems)
{
    win_count = 0;
    game_number = 1;
    prize = 1;
    this->num_problems = num_problems;
    this->level_difficulty = level_difficulty;
}

// ----------------------Member Functions ------------------------
// Introduction
void Flashcard::Introduction()
{
    cout << "Welcome to the game of practicing simple math problems. \n";
    cout << "Choose which math flashcards you would like to practice with. \n";
    cout << "Try to answer as fast as possible. \n";
    cout << "If you get at least 70% of the number of questions correct, you win ";
    cout << "a dollar for every question you get correct. \n \n";
}

// initialize numbers a and b
int Flashcard::choose_difficulty()
{
    cout << "Please choose an option: " << endl;
    cout << "[1] Beginner \n[2] Intermediate \n[3] Advanced " << endl;
    cin >> level_difficulty;
    return level_difficulty;
}

// Problem setup
void Flashcard::problem_setup()
{
    set_numbers();
    cout << "Problem number: " << game_number << endl;
    game_number++;
}

//Generating random numbers for a and b
void Flashcard::set_numbers()
{
    srand(time(NULL));
    switch (level_difficulty)
    {
    case 1:
        a = rand() % 13;
        b = rand() % 13;
        break;
    case 2:
        a = rand() % 51;
        b = rand() % 51;
        break;
    case 3:
        a = rand() % 101;
        b = rand() % 101;
        break;
    }
}

// Different modes of flashcards: add, subtract, multiply
void Flashcard::add()
{
    for (int i = 1; i <= num_problems; i++)
    {
        problem_setup();
        cout << a << " + " << b << endl;
        cin >> user_answer;
        computed_answer = a + b;
        correctAnswer(); // check if the user answer is correct

    }
}

void Flashcard::subtract()
{
    for (int i = 1; i <= num_problems; i++)
    {
        problem_setup();
        cout << a << " - " << b << endl;
        cin >> user_answer;
        computed_answer = a - b;
        correctAnswer(); // check if the user answer is correct

    }
}

void Flashcard::multiply()
{
    for (int i = 1; i <= num_problems; i++)
    {
        problem_setup();
        cout << a << " * " << b << endl;
        cin >> user_answer;
        computed_answer = a*b;
        correctAnswer(); // check if the user answer is correct

    }
}

// check if computed_answer = user_answer
bool Flashcard::correctAnswer()
{
    if (user_answer == computed_answer)
    {
        cout << "Correct! \n" << endl;
        win_count++;
        user_right = true;
    }
    else
    {
        cout << "Incorrect \n" << endl;
        win_count = win_count;
        user_right = false;
    }

    return user_right;
}

// Determine if the user has won the prize or not
bool Flashcard::userWins()
{
    if (win_count >= ceil(0.7*num_problems))
    {
        win = true;
        cout << "You got " << win_count << " problems correct " << endl;
        cout << "Congratualations! You have won $" << getPrize() << endl;
    }
    else
    {
        cout << "You got " << win_count << " prolems correct " << endl;
        cout << "You needed at least " << ceil(0.7*num_problems) << " problems correct " << endl;
        cout << "I'm sorry you did not win the prize \n";
        win = false;
    }

    return win;
}

// Set Prize
void Flashcard::setPrize()
{
    prize = win_count*prize;
}

// Get prize
int Flashcard::getPrize()
{
    setPrize();
    return prize;
}
