/* Daniel Scarbrough
Section C

Mines Student Class
*/

#include "MinesStudent.h"
using namespace std;

MinesStudent::MinesStudent() { //default constructor
    sadness = 0;
    knowledge = 10;
    dumbLuck = LuckAdjust() * 3;
    tiredness = 0;
    srand(time(0));
    timeLeft = 100;
    graduated = false;
    isSad = false; //soon.... 
    pregnancy = false;
    isWeekend = false;
    return;
}

int MinesStudent::LuckAdjust() { //Randombly adjust dumb luck 
    return ((rand() % 11) - 5) * 3;
}

void MinesStudent::Introduction() { //Print game rules
    cout << "Welcome to Mines. You need to earn 450 knowledge to graduate. \n(Or maybe you'll get lucky) \nBeing tired (tiredness > 50) will make your learning actions less effective." << endl;
    cout << "Try to graduate without being sad! (sadness > 50). \nSkipping class will come back to get you..." << endl;
    cout << "Good luck. Now register for your classes, you have two weeks!" << endl << endl;
}

void MinesStudent::StartWeek() { //Signifies a week (100 hours) is starting
    cout << "The school week is beginning!" << endl;
    timeLeft = 100;
    classHoursLeft = classHours * 3;
    isWeekend = false;
    return;
}

void MinesStudent::StartWeekend() { //The weekend starts (56 hours) PArtying is an option now
    cout << "It's the weekend!" << endl;
    timeLeft = 56;
    isWeekend = true;
    return;
}

void MinesStudent::DrinkCoffee() { //Reduces tiredness but adds sadness
    cout << "How many coffees do you need? " << endl;
    cin >> hourChoice;
    if (hourChoice > timeLeft) {
        cout << "You didn't have quite enough time for that many coffees.. \nyou had as many as you could." << endl;
        hourChoice = timeLeft;
    }
    tiredness -= 5 * hourChoice;
    timeLeft -= 1 * hourChoice;
    sadness += 1 * hourChoice;
    dumbLuck += LuckAdjust();
    cout << endl << "\"Tastes like sadness and dirt.\"" << endl << endl;
    return;
}

void MinesStudent::Study() { //study to gain knowledge. Increases knowledge, tiredness, and sadness.
    cout << "How many hours would you \"like\" to study? ";
    cin >> hourChoice;
    if (tiredness > 100) {
        cout << endl << "You were too tired and passed out immediately." << endl << endl;
        tiredness -= hourChoice;
        timeLeft -= hourChoice;
        return;
    }
    if (hourChoice > timeLeft) {
        hourChoice -= hourChoice - timeLeft;
        cout << endl << "You tried to study for more hours than there were left in the week. Proud of you." << endl << endl;
        knowledge += hourChoice * 2;
        tiredness += hourChoice * 4;
        sadness += hourChoice * 3;
        for (int i = 0; i < hourChoice; i++) {
            dumbLuck += LuckAdjust() - 2;
        }
        timeLeft -= hourChoice;
    }
    else {
        cout << endl << "Well... you tried." << endl << endl;
        knowledge += hourChoice * 3;
        tiredness += hourChoice * 2;
        sadness += hourChoice * 2;
        for (int i = 0; i < hourChoice; i++) {
            dumbLuck += LuckAdjust();
        }
        timeLeft -= hourChoice;
    }
    if (tiredness > 50) { //tiredness penalty
        cout << "You fell asleep while studying..." << endl << endl;
        knowledge -= hourChoice * (tiredness / 40);
    }
    return;
}

void MinesStudent::Register() { //determines how many hours of class you need per week
    cout << "How many credits would you like to register for? ";
    cin >> classHours;
    if (classHours < 12) {
        cout << endl << "Way to go big" << endl;
    }
    else if (classHours >= 12 && classHours <= 19) {
        cout << endl << "Average choice" << endl;
    }
    else {
        cout << endl << "LOL" << endl;
    }
    sadness += classHours * 2;

    cout << endl << endl;
    return;
}

void MinesStudent::Party() { //reduces sadness, increases tiredness, and greatly modifies dumb luck.
    if (timeLeft < 16) {
        cout << "Partying on a Sunday? You don't go to CU." << endl << endl;
        knowledge -= 1 * (timeLeft % 16 + 1);
        tiredness += 10;
        dumbLuck += (LuckAdjust() - 5) * 10;
    }
    else {
        cout << "Nice." << endl << endl;
        knowledge -= 4;
        tiredness += 5;
        sadness -= 30;
        dumbLuck += LuckAdjust() * 5;
    }
    if (tiredness > 50) {
        cout << "You fell asleep at the party" << endl << endl;
        sadness += 10;
        timeLeft -= 1;
    }
    timeLeft -= 5;
}

void MinesStudent::PartyHard() { //same as Party(), but modifies everything more. dumb luck is multiplied greatly
    if (timeLeft < 16) {
        cout << "Partying like this on a Sunday? What could go wrong?" << endl << endl;
        knowledge -= 2 * (timeLeft % 16 + 1);
        tiredness += 20;
        dumbLuck += LuckAdjust() - 10;
    }
    else {
        cout << "You were an animal." << endl << endl;
        knowledge -= 8;
        tiredness += 10;
        sadness -= 45;
        dumbLuck += LuckAdjust() * 3;
    }
    if (tiredness > 50) {
        cout << "You fell asleep at the party" << endl << endl;
        sadness += 10;
        timeLeft -= 2;
    }
    timeLeft -= 8;
    return;
}

void MinesStudent::Sleep() { //reduces sadness and tiredness
    cout << "How long would you like to sleep for? (Requires 1 hour to cry yourself to sleep) ";
    cin >> hourChoice;
    hourChoice += 1;
    if (hourChoice > timeLeft) {
        cout << endl << "There wasn't that much time left. You missed something important... probably." << endl << endl;
        hourChoice -= hourChoice - timeLeft;
        tiredness -= 3 * hourChoice;
        knowledge -= 1 * hourChoice;
        dumbLuck += LuckAdjust() * 2;
        sadness -= 1 * hourChoice;
    }
    else if (tiredness > 75) {
        cout << endl << "You were so tired you dreamt of sleeping." << endl << endl;
        tiredness -= 4 * hourChoice;
        dumbLuck += LuckAdjust();
        sadness -= 3 * hourChoice;
    }
    else {
        cout << endl << "You dreamt of math. How sad." << endl << endl;
        tiredness -= 2 * hourChoice;
        dumbLuck += LuckAdjust();
        sadness -= 2 * hourChoice;
    }
    timeLeft -= hourChoice;
    return;

}

void MinesStudent::Cry() { //reduces sadness
    cout << "How long would you like to cry for? ";
    cin >> hourChoice;
    if (hourChoice > timeLeft) {
        cout << endl << "You cried for longer than there was time for, which only made things worse." << endl << endl;
        hourChoice -= hourChoice - timeLeft;
        tiredness += 2 * hourChoice;
        dumbLuck += LuckAdjust();
        sadness += 1 * hourChoice;
    }
    else {
        cout << endl << "There there, it'll (maybe) get better." << endl << endl;
        sadness -= 3 * hourChoice;
        dumbLuck += LuckAdjust();
        tiredness += 1 * hourChoice;
    }
    timeLeft -= hourChoice;
    return;
}

void MinesStudent::GoToClass() { //goes to class, increasing knowledge, tiredness, and sadness.
    cout << "How many hours of class are you going to go to? ";
    cin >> hourChoice;
    if (isWeekend) {
        cout << endl << "It's the weekend, there aren't any classes. You goofed." << endl << endl;
        timeLeft -= 1;
        sadness += 10;
        tiredness += 3;
        return;
    }
    if (hourChoice > timeLeft) {
        cout << endl << "You went to more classes than there was time for, how is that even possible?" << endl << endl;
        hourChoice -= hourChoice - timeLeft;
        tiredness += 4 * hourChoice;
        dumbLuck += LuckAdjust();
        sadness += 3 * hourChoice;
        knowledge += 5 * hourChoice;
    }
    else if (hourChoice > classHoursLeft) {
        cout << endl << "You went to extra classes. Good for you." << endl << endl;
        tiredness += 3 * hourChoice;
        dumbLuck += LuckAdjust();
        sadness += 3 * hourChoice;
        knowledge += 5 * hourChoice;
        classHoursLeft = 0;
    }
    else {
        cout << endl << "Don't change the slide yet, please, please..... dang it." << endl << endl;
        tiredness += 2 * hourChoice;
        dumbLuck += LuckAdjust();
        sadness += 2 * hourChoice;
        knowledge += 4 * hourChoice;
        classHoursLeft -= hourChoice;
    }

    if (tiredness > 50) {
        cout << "You fell asleep in class..." << endl << endl;
        knowledge -= hourChoice * (tiredness / 40);
    }
    timeLeft -= hourChoice;
    return;
}

void MinesStudent::WeekChoice(int choice) {//switch to run selected choice
    switch (choice) {
    case 1:
        Study();
        break;
    case 2:
        GoToClass();
        break;
    case 3:
        DrinkCoffee();
        break;
    case 4:
        Sleep();
        break;
    case 5:
        Cry();
        break;
    default:
        cout << "You didn't enter a valid choice. +1 sadness for you." << endl << endl;
        sadness += 1;
        break;
    }
    return;
}

void MinesStudent::PrintWeekMenu() { //displays the menu of choices then the function to choose and run an option
    cout << "Choose an action." << endl;
    cout << "1: Study" << endl << "2: Go to class" << endl << "3: Drink Coffee" << endl << "4: Sleep" << endl << "5: Cry" << endl;
    cin >> menuChoice;
    WeekChoice(menuChoice);
    return;
}

void MinesStudent::WeekendChoice(int choice) {//switch to run selected choice
    switch (choice) {
    case 1:
        Study();
        break;
    case 2:
        GoToClass();
        break;
    case 3:
        DrinkCoffee();
        break;
    case 4:
        Sleep();
        break;
    case 5:
        Cry();
        break;
    case 6:
        Party();
        break;
    case 7:
        PartyHard();
        break;
    default:
        cout << "You didn't enter a valid choice. +1 sadness for you." << endl << endl;
        sadness += 1;
        break;
    }
    return;
}

void MinesStudent::PrintWeekendMenu() { //prints menu and calls choice function to run the selection
    cout << "Choose an action." << endl;
    cout << "1: Study" << endl << "2: Go to class" << endl << "3: Drink Coffee" << endl << "4: Sleep" << endl << "5: Cry" << endl << "6: Party" << endl << "7: Party Hard" << endl;
    cin >> menuChoice;
    WeekendChoice(menuChoice);
}

void MinesStudent::CheckStatus() { //displays current stats while time remains
    while (timeLeft > 0) {
        cout << "Your current stats are: \nKnowledge: " << knowledge << "\tTiredness: " << tiredness << "\tSadness: " << sadness << "\tDumb Luck: " << dumbLuck << endl;
        if (isWeekend) {
            cout << "There are " << timeLeft << " hours left in the weekend." << endl << endl;
            PrintWeekendMenu();
        }
        else {
            cout << "There are " << timeLeft << " hours left this week. You should go to " << classHoursLeft << " hours of classes." << endl << endl;
            PrintWeekMenu();
        }

    }

    cout << "That does it for this time period!" << endl << endl << endl;
    if (classHoursLeft > 0) {
        knowledge -= 2 * classHoursLeft;
    }
}

void MinesStudent::PrintPrize() { //determines the final prize using stats at the end of two weeks.
    cout << "School's done... let's see how you did and what you won!" << endl;
    cout << "Your final stats are: \nKnowledge: " << knowledge << "\tTiredness: " << tiredness << "\tSadness: " << sadness << "\tDumb Luck: " << dumbLuck << endl << endl;
    if (sadness > 50) {
        isSad = true;
    }
    if (knowledge > 450) {
        graduated = true;
    }
    if (dumbLuck < -30) {
        pregnancy = true;
    }
    else if (dumbLuck > 150) { //lucky graduation
        graduated = true;
    }

    cout << "In your time at Mines: ";

    if (pregnancy && !isSad) {
        cout << "you got pregnant." << endl << endl;
        return;
    }
    else if (pregnancy && isSad) {
        cout << "you got pregnant and cried." << endl << endl;
        return;
    }

    if (graduated && !isSad) {
        cout << "you got your Bachelor's degree!" << endl << endl;
        return;
    }
    else if (graduated && isSad) {
        cout << "you got a Bachelor's degree. And tears. Mostly tears." << endl << endl;
        return;
    }
    else if (!graduated && !isSad) {
        cout << "you got a certificate for trying." << endl << endl;
        return;
    }
    else if (!graduated && isSad) {
        cout << "you got a participation awawrd and tears." << endl << endl;
        return;
    }
    else {
        cout << "you won tears just because!" << endl << endl;
        return;
    }
}

//The code below is what should be put into the main.cpp file for the class to be run as desired.

//#include "MinesStudent.h"
//
//int main() {
//	MinesStudent player; //generate the MinesStudent object named player
//	player.Introduction(); //print intro
//	player.Register(); //register for classes
//	player.StartWeek(); //start week 1
//	player.CheckStatus(); //check status and run until week 1 ends
//	player.StartWeekend(); //start the weekend
//	player.CheckStatus(); //check status and run until weekend ends
//	player.StartWeek(); //start week 2
//	player.CheckStatus(); //check status and run until week 2 ends
//	player.PrintPrize(); //Print the final prize
//
//	return 0;
//}