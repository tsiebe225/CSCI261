#include "hangman.h"
#include "Flashcard.h"
#include "SlotMachine.h"
#include "MinesStudent.h"

#include <iostream>

//Shared with Bethany Wilson, Kyle Kluherz, Dyaln Ritger, Carly Best, David Borkert, Madison Johnson

using namespace std;
int main() {
    Hangman runOne;
    runOne.Intro();
    do {
        runOne.GetLetter();
        runOne.ShowWord();
        cout << endl;

    } while (runOne.FirstLetterCorrect == false || runOne.SecondLeterCorrect == false || runOne.ThirdletterCorrect == false || runOne.FourthLeterCorrect == false || runOne.FifthLetterCorrect == false || runOne.SixthLeterCorrect == false || runOne.SeventhLetterCorrect == false || runOne.EightLeterCorrect == false || runOne.NinthLetterCorrect == false || runOne.TenthLeterCorrect == false);
    runOne.Gift();
    
    Flashcard flashOne(3);
    flashOne.choose_difficulty();
    flashOne.problem_setup();
    flashOne.set_numbers();
    flashOne.multiply();
    flashOne.correctAnswer();
    flashOne.userWins();
    flashOne.setPrize();
    flashOne.getPrize();

       
    SlotMachine SlotRun1;
    for (int j = 0; j < 5; ++j) {
        SlotRun1.PullLever();
        SlotRun1.DisplaySlot();
        if (SlotRun1.CheckSlot()) {
            SlotRun1.GetPrize();
            cout << "You won" << endl;
        }
        else {
            cout << "You did not win" << endl;
        }
    }
    MinesStudent player; //generate the MinesStudent object named player
    player.Introduction(); //print intro
    player.Register(); //register for classes
    player.StartWeek(); //start week 1
    player.CheckStatus(); //check status and run until week 1 ends
    player.StartWeekend(); //start the weekend
    player.CheckStatus(); //check status and run until weekend ends
    player.StartWeek(); //start week 2
    player.CheckStatus(); //check status and run until week 2 ends
    player.PrintPrize(); //Print the final prize



    return 0;
}