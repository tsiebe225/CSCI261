
/* CSCI261 HW 11: Class Fun
*
* Description: Header file for Slot Machine
*
* Author:Derek Hart
*
* This file creates a slot machine class. It contains the prize string,
* the slot values, the introduction as private variables. It also contains
* the default constructor as well as the functions for playing, displaying,
* checking slot values, and for displaying the prize string.
*/

#pragma once

#include <string>
using namespace std;

class SlotMachine {
private:
    //Declare variables for prize, slot values, and introduction
    string prize;
    int slotVals[3];
    void Introduction();

public:
    SlotMachine(); // Default Constructor
    void PullLever(); // Generate random slot values
    void DisplaySlot(); // Display slot values
    bool CheckSlot(); // Check if slot values are the same
    string GetPrize(); // Present winner with prize

};