//CSCI261 Section C
//Tanner Siebe

#include "hangman.h"
#include<iostream>


using namespace std;

Hangman::Hangman() {
    firstLetter = 'a';
    secondLeter = 'f';
    thirdLetter = 't';
    fourthLetter = 'e';
    fifthLetter = 'r';
    sixthLeter = 's';
    seventhLetter = 'h';
    eightLeter = 'o';
    ninthLetter = 'c';
    tenthLetter = 'k';

    FirstLetterCorrect=false;
    SecondLeterCorrect = false;
    ThirdletterCorrect = false;
    FourthLeterCorrect = false;
    FifthLetterCorrect = false;
    SixthLeterCorrect = false;
    SeventhLetterCorrect = false;
    EightLeterCorrect = false;
    NinthLetterCorrect = false;
    TenthLeterCorrect = false;
};

void Hangman::Intro() {
    cout << "Lets play a round of hangman, the word is 10 letters have fun!" << endl;
    cout << "If you get it right you get a warm fuzzy feeling inside of pure joy!" << endl;
    cout << "Let's get started! Enter your first guess." << endl;
}
void Hangman::GetLetter() {
    cin >> userGuess;
}
void Hangman::Gift() {
    cout << "Yay you won here is your prize!!! :) a terrible excuse of a smiley face!" << endl;
}
bool Hangman::Finished() {
    return false;
}
void Hangman::ShowWord() {
    if ((userGuess == 'a')||(FirstLetterCorrect) ){
        FirstLetterCorrect = true;
        cout << "a";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 'f') || (SecondLeterCorrect) ){
        SecondLeterCorrect = true;
        cout << "f";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 't') || (ThirdletterCorrect) ){
        ThirdletterCorrect = true;
        cout << "t";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 'e') || (FourthLeterCorrect) ){
        FourthLeterCorrect = true;
        cout << "e";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 'r') || (FifthLetterCorrect) ){
         FifthLetterCorrect= true;
         cout << "r";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 's') || (SixthLeterCorrect) ){
        SixthLeterCorrect = true;
        cout << "s";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 'h') || (SeventhLetterCorrect)) {
        SeventhLetterCorrect = true;
        cout << "h";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 'o') || (EightLeterCorrect)) {
        EightLeterCorrect = true;
        cout << "o";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 'c') || (NinthLetterCorrect)) {
        NinthLetterCorrect = true;
        cout << "c";
    }
    else {
        cout << "_";
    }
    if ((userGuess == 'k') || (TenthLeterCorrect) ){
        TenthLeterCorrect = true;
        cout << "k";
    }
    else {
        cout << "_";
    }
    cout << " Enter your next guess.";
}
/* Below is a sample implementation of the class
Hangman runOne;
runOne.Intro();
do {
runOne.GetLetter();
runOne.ShowWord();
cout << endl;

} while (runOne.FirstLetterCorrect == false || runOne.SecondLeterCorrect == false || runOne.ThirdletterCorrect == false || runOne.FourthLeterCorrect == false || runOne.FifthLetterCorrect == false || runOne.SixthLeterCorrect == false || runOne.SeventhLetterCorrect == false || runOne.EightLeterCorrect == false || runOne.NinthLetterCorrect == false || runOne.TenthLeterCorrect == false);
runOne.Gift();

*/
