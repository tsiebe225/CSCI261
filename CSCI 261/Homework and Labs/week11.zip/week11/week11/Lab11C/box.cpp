#include"box.h"
#include<math.h>


const int Box::DEFAULT_DIMENSION = 1;

Box::Box() {
    height = DEFAULT_DIMENSION;
    width = DEFAULT_DIMENSION;
    depth = DEFAULT_DIMENSION;
}
Box::Box(double heightInp, double widthInp, double depthInp) {
    if (heightInp <= 0) {
        height = DEFAULT_DIMENSION;
    }
    else
    {
        {
            height = heightInp;
        }
    }
    if (widthInp <= 0) {
        width = DEFAULT_DIMENSION;
    }
    else
    {
        {
            width = widthInp;
        }
    }
    if (depthInp <= 0) {
        depth = DEFAULT_DIMENSION;
    }
    else
    {
        {
            depth = depthInp;
        }

    }
}
void Box::SetHeight(double heightSet) {
    if (heightSet <= 0) {
        height = DEFAULT_DIMENSION;
    }
    else
    {
        {
            height = heightSet;
        }
    }
}
void Box::SetWidth(double widthSet) {
    if (widthSet <= 0) {
        width = DEFAULT_DIMENSION;
    }
    else
    {
        {
            width = widthSet;
        }
    }
}
void Box::SetDepth(double depthSet) {
    if (depthSet <= 0) {
        depth = DEFAULT_DIMENSION;
    }
    else
    {
        {
            depth = depthSet;
        }
    }
}
double Box::GetHeight() {
    return height;
}
double Box::GetWidth() {
    return width;
}
double Box::GetDepth() {
    return depth;
}
double Box::Volume() {
    return (height*width*depth);
}