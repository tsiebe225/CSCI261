#pragma once
class Box
{
public:
    Box();//initiate with default
    Box(double heightInp, double widthInp, double depthInp);//initiate with inputs

    static const int DEFAULT_DIMENSION;

    double GetHeight();
    double GetWidth();
    double GetDepth();
    double Volume();

    void SetHeight(double setHeight);
    void SetWidth(double setWidth);
    void SetDepth(double setDepth);

    

private:
    double height;
    double width;
    double depth;
};

