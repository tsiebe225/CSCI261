/* CSCI261 Lab 11C: Box Class
*
* Author: YOUR NAME
*
* This program executes a test suite to ensure the proper design of Box class.
*
* For this lab, you only need to modify box.h and box.cpp.
*
*/
#include <cstdlib>
#include <iostream>
#include "test.h"
using namespace std;


int main() {

    RunAllTests();

    // Exit program.
    return 0;

}