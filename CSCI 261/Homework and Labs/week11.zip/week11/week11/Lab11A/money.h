/* CSCI261 Lab 11A: Money Class
*
* Descriptiona: Header file for Money Class
*
* Author:
*
*/
#pragma once

class Money {

    public:
        Money();
        Money(int myDollars, int myCents);

        int GetDollars();
        int GetCents();
        void SetDollars(int setDollars);
        void SetCents(int setCents);
    private:
        int dollars;
        int cents;

};