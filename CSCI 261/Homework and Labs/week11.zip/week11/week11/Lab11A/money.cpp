/* CSCI261 Lab 11A: Money Class
*
* Description: Implementation file for Money Class
*
* Author:
*
*/
#include "money.h"
Money::Money() {

}
Money::Money(int myDollars, int myCents) {
    dollars = myDollars;
    cents = myCents;
}
int Money::GetDollars() {
    return dollars;
}
int Money::GetCents() {
    return cents;
}
void Money::SetCents(int setCents) {
    cents = setCents;
}
void Money::SetDollars(int setDollars) {
    dollars = setDollars;
}
