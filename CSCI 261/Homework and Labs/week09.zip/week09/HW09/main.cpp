//Authoer:Tanner Siebe
//HW09 Reading and writing wtih data files


#include <iostream>
#include <fstream>
#include<math.h>
#include<string>
using namespace std;

int main() {
    int wordPointVal;
    int wordRunningTot;
    int wordLength;
    int letterPointVal;
    string word;
    char letter;


    ifstream pointVals("HW09points.txt");//declare ifstream object and open the file
    ifstream words("HW09words.txt");
    ofstream message("message.txt");

                                     // check for an error
    if (pointVals.fail()) {
        cerr << "Error opening input file";
        exit(1);
    }
    if (words.fail()) {
        cerr << "Error opening input file";
        exit(1);
    }
    if (message.fail()) {
        cerr << "Error opening output file";
        exit(1);
    }

    // read the data and do something with it
    while (!pointVals.eof()) {
        pointVals >> wordPointVal;
        while (!words.eof()) {
            wordRunningTot = 0;
            getline(words, word);
            wordLength = word.length();


            for (int i = 0; i < wordLength; ++i) {
                letter = word.at(i);
                switch (letter) {
                case 'e':
                case't':
                case'a':
                case'o':
                case'n':
                    letterPointVal = 10;
                    break;
                case 'r':
                case 'i':
                case 's':
                case 'h':
                case 'd':
                    letterPointVal = 20;
                    break;
                case 'l':
                case 'f':
                case 'c':
                case 'm':
                case 'u':
                    letterPointVal = 30;
                    break;
                case 'g':
                case 'y':
                case 'p':
                case 'w':
                case 'b':
                    letterPointVal = 40;
                    break;
                case 'v':
                case 'k':
                case 'j':
                case 'x':
                case 'q':
                    letterPointVal = 50;
                    break;
                case 'z':
                    letterPointVal = 60;
                    break;
                default:
                    letterPointVal = 0;
                    break;
                }
                wordRunningTot = wordRunningTot + letterPointVal;
            }
            if (wordRunningTot == wordPointVal) {
                message << word << endl;
                wordRunningTot = 0;
                break;
            }
            else {
                wordRunningTot = 0;
            }
        }
    }

    pointVals.close(); // close the file
    words.close();
    message.close();

    return 0;
}