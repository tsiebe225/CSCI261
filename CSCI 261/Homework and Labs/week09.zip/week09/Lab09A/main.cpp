#include <iostream>
#include <fstream>
using namespace std;

int main() {
    int count=0;
    int sum = 0;
    int x;
    ifstream pop("populations.txt"); // declare ifstream object and open the file

                                     // check for an error
    if (pop.fail()) {
        cerr << "Error opening input file";
        exit(1);
    }

    // read the data and do something with it
    while (!pop.eof()) {
        pop >> x;
        count = count + 1;
        sum = sum + x;
    }

    pop.close(); // close the file
    cout << "The average population of " << count << " cities is " << (sum / count)+1 << endl;//plus one for rounding

    return 0;
}