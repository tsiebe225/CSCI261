#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    char letter;
    char place1;
    string place;
    int length;
    ifstream origMessage("secretMessage.txt"); // declare ifstream object and open the file
    ofstream solvedMessage("solvedMessage.txt");

    if (solvedMessage.fail()) {
        cerr << "Error opening output file";
        exit(1);
    }

                                     // check for an error
    if (origMessage.fail()) {
        cerr << "Error opening input file";
        exit(1);
    }

    // read the data and do something with it
    while (!origMessage.eof()) {
        getline(origMessage, place);
        length = place.length();
        for (int i = 0; i < length; ++i) {
            place1 = place.at(i);
            if (place1 == '~') {
                solvedMessage << " ";
            }
            else if (place1 == '\\n') {
                solvedMessage << endl;
            }
            else if ((i + 1) == length) {
                solvedMessage << endl;
            }
            else {
                place1 = place1 + 1;
                solvedMessage << place1;
            }
        }

        
    }

    origMessage.close(); // close the file
    solvedMessage.close();

    return 0;
}