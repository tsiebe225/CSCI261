/* CSCI261 Lab 06B: stringTest
*
* Author: Tanner Siebe
*
* This program executes some tests that illustrate the properties
* and behaviors of strings.
*/
#include <cstdlib>
#include <iostream>
#include <string>
#include<cstring>
using namespace std;

void RunAllTests();

int main() {

    cout << "Testing your functions...\n\n";
    RunAllTests();

    // Exit program.
    return 0;
}


// A generic test function, that simply prints "PASSED" if b is true
// and otherwise prints false. Do not modify this function.
void Test(string message, bool b)
{
    cout.width(30);
    cout << message;
    cout.width(10);
    if (b)
        cout << " PASSED\n";
    else
        cout << " FAILED\n";
}

// Returns the length of a string
int StringLength(string s)
{
    return s.length();
}

// Converts a string to the empty string
string StringClear(string s)
{
    s.clear();
    return s; // stub
}

// Returns true if the string is empty
bool StringEmpty(string s)
{
    if (s.empty()) {
        return true;
    }
    else {
        return false; // stub
    }
}

// Returns the character of a string at a given index
char CharAt(string s, int index)
{
    return s.at(index); // stub
}

// Returns a concatenation of strings left and right
string StringAppend(string left, string right)
{
    return left += right; // stub
}

// Returns the result of inserting a string into another
string StringInsert(string s, string toInsert, int index)
{
    return s.insert(index,toInsert); // stub
}

// Erases part of a string
string StringErase(string s, int index, int length)
{
    return s.replace(index,length,""); // stub
}

// Replaces part of a string
string StringReplace(string s, string textToReplace, string replaceWith)
{
    return s.replace(s.find(textToReplace),textToReplace.length(),replaceWith); // stub
}

// Returns the first index of character c in string s
int StringFind(string s, char c)
{
    return s.find(c); // stub
}

// Returns the last index of character c in string s
int StringRFind(string s, char c)
{                                                       //working on this function
    return 0; // stub
}

// Returns the index of the first occurance of character c
int StringFirst(string s, char c)
{
    return 0; // stub
}

// Returns the index of the first character in the string that is not c
int StringFirstNot(string s, char c)
{
    return 0; // stub
}

// Returns part of a string
string StringSubstring(string s, int index, int length)
{
    return ""; // stub
}

// Returns the first name, given a full name
string FirstName(string s)
{
    return ""; // stub
}

// Returns the middle name, given a full name
string MiddleName(string s)
{
    return ""; // stub
}

// Returns the last name, given a full name
string LastName(string s)
{
    return ""; // stub
}

// Returns a capitalized version of a string
string Capitalize(string s)
{
    return ""; // stub
}

// Returns true if the string contains character c
bool Include(string s, char c)
{
    return false; // stub
}

// Returns a string substituting character target with character replacement
string Substitute(string s, char target, char replacement)
{
    return ""; // stub
}

// Test suite. You should read, but not modify, this function.
void RunAllTests()
{
    Test("Testing length()", StringLength("Now") == 3);
    Test("Testing clear()", StringClear("Is") == "");
    Test("Testing empty()", StringEmpty(""));
    Test("Testing at()", CharAt("Elephant", 3) == 'p');
    Test("Testing append()", StringAppend("There's a ", "natural mystic.") == "There's a natural mystic.");
    Test("Testing insert()", StringInsert("If you carefully.", "listen ", 7) == "If you listen carefully.");
    Test("Testing erase()", StringErase("This could be the first trumpet", 6, 19) == "This crumpet");
    Test("Testing replace()", StringReplace("Strings are not the way", "Strings", "Things") == "Things are not the way");
    Test("Testing find()", StringFind("Have to face reality now.", 'o') == 6);
    Test("Testing rfind()", StringRFind("Have to face reality now.", 'o') == 22);
    Test("Testing find_first_of()", StringFirst("XXXXOXXX", 'O') == 4);
    Test("Testing find_first_not_of()", StringFirstNot("XXXXOXXX", 'X') == 4);
    Test("Testing substr()", StringSubstring("Such a natural mystic", 7, 7) == "natural");
    Test("Testing firstName()", FirstName("Robert Nesta Marley") == "Robert");
    Test("Testing middleName()", MiddleName("Robert Nesta Marley") == "Nesta");
    Test("Testing lastName()", LastName("Robert Nesta Marley") == "Marley");
    Test("Testing capitalize()", Capitalize("eager") == "Eager");
    Test("Testing include()", Include("Robert", 'o'));
    Test("Testing substitute()", Substitute("The Gxxgle", 'x', 'o') == "The Google");
}
