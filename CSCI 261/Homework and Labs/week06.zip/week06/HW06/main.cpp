/* CSCI 261:HW06
* Author: Tanner Siebe
*
*
*/

#include <iostream>   // For cin, cout, etc.
#include <math.h>
#include <string>
#include <iomanip>

using namespace std;  // For standard namespace 

struct card {
    int rank;
    string suit;
};

void CardGen(card& cardEx) {     //randCard function same thing
    int suitPlace;
    cardEx.rank = ((rand() % 8) + 2);
    suitPlace = ((rand() % 4 + 1));
    if (suitPlace == 1) {
        cardEx.suit = "Heart";
    }
    else if (suitPlace == 2) {
        cardEx.suit = "Diamonds";
    }
    else if (suitPlace == 3) {
        cardEx.suit = "Clubs";
    }
    else if (suitPlace == 4) {
        cardEx.suit = "Spades";
    }
}


int main() {
    card card1;
    int dealerTot = 0;
    int playerTot = 0;
    string playerAnsToPlay;
    string playerAnsToHit;
    string turn = "Players";
    int playing = 1;
   
    while (playing == 1) {
        cout << "Would you like to play Blackjack? (Yes or No)" << endl;
        cin >> playerAnsToPlay;
        if (playerAnsToPlay == "Yes") {
            dealerTot = 0;
            playerTot = 0;
            playing = 1;
            turn = "Players";

            CardGen(card1);
            cout << "Dealer shows a " << card1.rank << " of " << card1.suit << endl;
            dealerTot = card1.rank + dealerTot;
            cout << "Dealer total is: " << dealerTot << endl;

            CardGen(card1);
            cout << "You were dealt the " << card1.rank << " of " << card1.suit << endl;
            playerTot = card1.rank;
            CardGen(card1);
            cout << "You were dealt the " << card1.rank << " of " << card1.suit << endl;
            playerTot = playerTot + card1.rank;
            cout << "Your total is: " << playerTot << endl;

            while (turn == "Players") {
                cout << "Do you want to 'Hit' or 'Stay'?" << endl;
                cin >> playerAnsToHit;
                if (playerAnsToHit == "Hit") {
                    CardGen(card1);
                    cout << "You were dealt the " << card1.rank << " of " << card1.suit << endl;
                    playerTot = playerTot + card1.rank;
                    cout << "Your total is: "<<playerTot << endl;
                    if (playerTot > 21) {
                        cout << "You busted,Dealer wins!" << endl;
                        turn = "No ones";
                    }
                    else if (playerTot == 21) {
                        cout << "BlackJack you win!" << endl;
                        turn = "No ones";
                    }
                }
                else {
                    turn = "Dealers";
                }
            }
            while (turn == "Dealers") {
                if (dealerTot < 17) {
                    CardGen(card1);
                    cout << "Dealer was dealt the " << card1.rank << " of " << card1.suit << endl;
                    dealerTot = dealerTot + card1.rank;
                    cout << "Dealer total is: " << dealerTot << endl;
                    if (dealerTot == 21) {
                        cout << "Blackjack, dealer wins" << endl;
                        turn = "No ones";
                    }
                    if (dealerTot > 21) {
                        cout << "Dealer busted! You win" << endl;
                        turn = "No Ones";
                    }
                }
                if ((dealerTot < 21) && (dealerTot >= 17)) {
                    if (dealerTot < playerTot) {
                        cout << "Player wins with " << playerTot << endl;
                        turn = "No Ones";
                    }
                    if (dealerTot > playerTot) {
                        cout << "Dealer wins with " << dealerTot << endl;
                        turn = "No ones";
                    }
                    if (dealerTot == playerTot) {
                        cout << "Round ends in tie with scores of " << playerTot << endl;
                        turn = "No ones";
                    }
                }
            }

        }
        else {
            playing = 0;
            return 0;
        }
    }




  
    return 0; // program ended fine 

}