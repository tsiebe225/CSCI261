/* CSCI 261 Lab 06A: Triangle using structs
*
* Author:Tanner Siebe
*
* using structs to classify traingles
*/

// The include section adds extra definitions from the C++ standard library.
#include <iostream> 	// For cin, cout, etc.
#include <cmath>		// For fabs
using namespace std;

// TODO #1: Define Triangle struct

struct Triangle {
    double sideOne;
    double sideTwo;
    double sideThree;
};

// TODO #2: Define HaveUserEnterTriangle() function

void HaveUserEnterTriangle(Triangle& triangle) {
    cout << "Enter side lengths for triangle:";
    cin >> triangle.sideOne >> triangle.sideTwo >> triangle.sideThree;
    return;
}

// TODO #3: Define OrderTriangleSides() function
void OrderTriangleSides(Triangle& triangle) {
    double shortSide;
    double midSide;
    double longSide;

    if ((triangle.sideOne < triangle.sideTwo) && (triangle.sideOne < triangle.sideThree)) {
        shortSide = triangle.sideOne;
        if (triangle.sideTwo < triangle.sideThree) {
            midSide = triangle.sideTwo;
            longSide = triangle.sideThree;
        }
        else {
            midSide = triangle.sideThree;
            longSide = triangle.sideTwo;
        }
    }
    else if ((triangle.sideTwo < triangle.sideOne) && (triangle.sideTwo < triangle.sideThree)) {
        shortSide = triangle.sideTwo;
        if (triangle.sideOne < triangle.sideThree) {
            midSide = triangle.sideOne;
            longSide = triangle.sideThree;
        }
        else {
            midSide = triangle.sideThree;
            longSide = triangle.sideOne;
        }
    }
    else if ((triangle.sideThree < triangle.sideOne) && (triangle.sideThree < triangle.sideTwo)) {
        shortSide = triangle.sideThree;
        if (triangle.sideOne < triangle.sideTwo) {
            midSide = triangle.sideOne;
            longSide = triangle.sideTwo;
        }
        else {
            midSide = triangle.sideTwo;
            longSide = triangle.sideOne;
        }
    }
    triangle.sideOne = shortSide;
    triangle.sideTwo = midSide;
    triangle.sideThree = longSide;
    return;
}

// TODO #4: Define AreTrianglesEquivalent() function

bool AreTrianglesEquivalent(Triangle triangle1, Triangle triangle2) {
    if ((triangle1.sideOne == triangle2.sideOne) && (triangle1.sideTwo == triangle2.sideTwo) && (triangle1.sideThree == triangle2.sideThree)) {
        return true;
    }
    else {
        return false;
    }

}


int main() {
    // Create two variables of our Triangle struct
    Triangle triangle1, triangle2;

    // Prompt the user to enter in the sides of each triangle
    HaveUserEnterTriangle(triangle1);
    HaveUserEnterTriangle(triangle2);

    // Order the sides for each triangle from smallest to largest
    OrderTriangleSides(triangle1);
    OrderTriangleSides(triangle2);

    // Determine if the two triangles are equivalent triangles based on side length
    if (AreTrianglesEquivalent(triangle1, triangle2)) {
        cout << "The two triangles are equivalent." << endl;
    }
    else {
        cout << "The two triangles are not equivalent." << endl;
    }

    return 0;
}
