/* CSCI 261 LAB03A
* Author:Tanner Siebe
*
* Triangle Classifcation
*/

#include <iostream>   // For cin, cout, etc.
#include <iomanip>
using namespace std;  // For standard namespace 

int main() {

    double sideOne;
    double sideTwo;
    double sideThree;
    double nonLongSide1;
    double nonLongSide2;
    double longSide;

    cout << "Enter side one length:";
    cin >> sideOne;
    cout << "Enter side two length:";
    cin >> sideTwo;
    cout << "Enter side three length:";
    cin >> sideThree;
    
    /*Found it to be simpler to transfer inputs to variables to allow side lengths to be input in any order and more flexible with code. Doing this allows just one if else string to be made 
    to determine if it is acute, obtuse or right as opposed to having to do more cases that are all going to be the same aside from the variables in each position. Much more simplistic and easy to
    debug. It also saved  roughly 24 lines of code due to the not having to repeat the structure each time for the other possible cases. 
    */
   
    
    if ((sideOne - sideTwo < 0) && (sideThree - sideTwo < 0)) {
    longSide=sideTwo;
    nonLongSide1 = sideOne;
    nonLongSide2 = sideThree;
    }

    else if ((sideTwo - sideOne < 0) && (sideThree - sideOne < 0)) {
    longSide = sideOne;
    nonLongSide1 = sideTwo;
    nonLongSide2 = sideThree;
    }
    else if ((sideTwo - sideThree < 0) && (sideOne - sideThree < 0)) {
    longSide = sideThree;
    nonLongSide1=sideOne;
    nonLongSide2 = sideTwo;
    }
    else if ((sideTwo == sideOne) && (sideTwo == sideThree)) {
        cout << "Forms an acute triangle.";
    }

    if (nonLongSide1 + nonLongSide2 <= longSide) {
        cout << "Trianlge cannot be made with these side lengths." << endl;
    }

    if (nonLongSide1 + nonLongSide2 > longSide) {
        if (((pow(nonLongSide1, 2) + pow(nonLongSide2, 2) < pow(longSide, 2)))) {
            cout << "Forms obtuse triangle." << endl;
        }
        else if ((pow(nonLongSide1, 2) + pow(nonLongSide2, 2) > pow(longSide, 2))) {
            cout << "Forms acute triangle." << endl;
        }
        else if (fabs((pow(nonLongSide1, 2) + pow(nonLongSide2, 2) - pow(longSide, 2))) <= .0001) {
            cout << "Forms right traingle." << endl;
        }
    }

  
        
    return 0; // program ended fine 

}