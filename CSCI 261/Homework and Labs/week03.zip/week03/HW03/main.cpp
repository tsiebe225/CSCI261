/* CSCI 261 HW03
* Author: Tanne Siebe
*
* Add more complete description here...
*/

#include <iostream> 
#include <string>
#include <iomanip>
#include <math.h>
#include <ctime>
#include <cstdlib>
using namespace std;  // For standard namespace 

int main() {

    /******** MODIFY OR INSERT CODE BELOW HERE ********/

    char playerOneInput;
    char playerTwoInput;
    srand(time(0));


       
    cout << "Welcome one and all to around of Rock, Paper Scissors! (Enter P,R or S)" << endl;
    cout << "Player one's choice:";
    cin >> playerOneInput;

    playerTwoInput = rand() % 3;

    if (playerTwoInput == 0) {
        playerTwoInput = playerTwoInput + 82;
    }
    else if (playerTwoInput == 1) {
        playerTwoInput = playerTwoInput + 79;
    }
    else if (playerTwoInput == 2) {
        playerTwoInput = playerTwoInput + 81;
    }


    cout << "Computers choice:" << playerTwoInput << endl;

    if (playerOneInput >= 90) {
        playerOneInput = playerOneInput - 32;
    }
    
    if (playerOneInput == playerTwoInput) {
        cout << "Tie" << endl;
    }
    if (playerOneInput == 82) {
        if (playerTwoInput == 83) {
            cout << "Rock beats scissors, player one wins!" << endl;
        }
        else if (playerTwoInput == 80) {
            cout << "Paper beats rock, the computer wins!" << endl;
        }
    }
    if (playerOneInput == 83) {
        if (playerTwoInput == 82) {
            cout << "Rock beats scissors, the computer wins!" << endl;
        }
        else if (playerTwoInput == 80) {
            cout << "Scissors beats paper, player one wins!" << endl;
        }
    }
    if (playerOneInput == 80) {
        if (playerTwoInput == 82) {
            cout << "Paper beats rock, player one wins!" << endl;
        }
        else if (playerTwoInput == 83) { 
            cout << "Scissors beats paper, the computer wins!" << endl;
        }
    }

    /******** MODIFY OR INSERT CODE ABOVE HERE ********/

    return 0; // program ended fine 

}
