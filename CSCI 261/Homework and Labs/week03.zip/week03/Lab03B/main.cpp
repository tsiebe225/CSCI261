/* CSCI 261 Lab03B: Triangles Classifier + Options Menu
*
* Author: Tanner Siebe
*
* The goal of this lab is to practice the use of if-else statements to classify triangles based on their sides.
* It will also teach you how to correctly compare double values for equality using a tolerance factor and
* the use of a menu of options using the switch statement.
*/

#include <iostream> // For cin, cout, etc.
#include <string>   // For string class
#include <cmath>    // For math functions

using namespace std;

const double TOLERANCE = 0.0001;

int main() {

    int option;               // to store the user's option (1-5)
    double inputA, inputB, inputC;  // to store user's side measurements
    double a, b, c;           // to copy side measurements such that c >= a and c >= b
    bool isTriangle = false;  // states whether a,b,c can be used as sides of a triangle

    do {  // we haven't learned loops yet, but you can guess what this do-while does 
          // show the menu 
        cout << "\n1. Enter measurements\n";
        cout << "2. Print measurements\n";
        cout << "3. Check triangle feasibility\n";
        cout << "4. Classify triangle\n";
        cout << "5. Exit\n";

        // read user's choice
        cout << "Please, choose an option: ";
        cin >> option;

        // ignore option if not 1-5
        if (option < 1 || option > 5) {
            cout << "Invalid option!\n";
            continue;
        }

        /******** INSERT YOUR CODE BELOW HERE ********/

        switch (option) {
        case 1:
            cout << "What is the value of side A,B and C? (C shoudl be the largest value);" << endl;
            cin >> inputA >> inputB >> inputC;
            if ((inputA <= 0) || (inputB <= 0) || (inputC <= 0)) {
                cout << "Error" << endl;
                return 0;
            }
            if ((inputA < inputC) && (inputB < inputC)) {
                c = inputC;
                a = inputA;
                b = inputB;
            }
            else if ((inputA < inputB) && (inputC < inputB)) {
                c = inputB;
                a = inputA;
                b = inputC;
            }
            else if ((inputB < inputA) && (inputC < inputA)) {
                c = inputA;
                a = inputC;
                b = inputB;
            }
            else if ((inputA == inputB) && (inputB == inputC) && (inputA ==inputC)) {
                a = inputA;
                b = inputB;
                c = inputC;
            }
            break;

        case 2:
            cout << "The side lengths are " << a << ", " << b << " and " << c << "." << endl;
            break;

        case 3:

            isTriangle = false;

            if ((c < (b + a)) && (b < (c + a)) && (a < (b + c))) {
                isTriangle = true;
            }
            if (isTriangle) {
                cout << "Acceptable triangle." << endl;
            }
            else {
                cout << "Triangle unacceptable." << endl;
            }


            break;

        case 4:
            if (isTriangle) {
                if (((pow(a, 2) + pow(b, 2) < pow(c, 2)))) {
                    cout << "Forms obtuse Triangle." << endl;
                }
                else if ((pow(a, 2) + pow(b, 2) > pow(c, 2))) {
                    cout << "Forms acute Triangle." << endl;
                }
                else if (fabs((pow(a, 2) + pow(b, 2) - pow(c, 2))) <= .0001) {
                    cout << "Forms right traingle." << endl;
                }
            }
            else {
                cout << "No triangle can be made.";
            }
                
            break;
        case 5:
            cout<<"Ending program.";
            break;
        }
        
        /******** INSERT YOUR CODE ABOVE HERE ********/
    } while (option != 5);

    return EXIT_SUCCESS; // signals the operating system that our program ended OK.
} 