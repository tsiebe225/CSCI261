/* CSCI 261 Homework 01: Hello World and ASCII Art
*
* Author: Tanner Siebe (_INSERT_YOUR_NAME_HERE_)
*
* Smiley face and basic facts variable test
*/

// The include section adds extra definitions from the C++ standard library.
#include <iostream> // For cin, cout, etc.
#include <string>   // For string class

// We will (most of the time) use the standard library namespace in our programs.
using namespace std;

// Define any constants or global variables below this comment.

// Must have a function named "main", which is the starting point of a C++ program.
int main() {

    /******** INSERT YOUR CODE BELOW HERE ********/

    cout << "Hello Tanner!!" << endl; // add your name 


    int userAge = 19;
    int userHeightFeet = 6;
    int userHeightInches = 7;
    float userGPA = 3.5;


    cout << "My name is Tanner Siebe." << endl;
    cout << "I am " << userHeightFeet << " feet " << userHeightInches << " inches tall." << endl;
    cout << "My GPA at CSM is " << userGPA <<"."<<endl;

    cout << "Here is a smiley face!" << endl;


    cout << "             x" << endl;
    cout << "            xxx" << endl;
    cout << "           xxxxx" << endl;
    cout << "          xxxxxxx" << endl;
    cout << "          xxxxxxx" << endl;
    cout << "        xxxxxxxxxxx" << endl;
    cout << "    xxxxxxxxxxxxxxxxxxxx" << endl;
    cout << "        ////// \\\\\\\\\\\\    "  << endl; //for some reason this one is inconsistent with how it shows up
    cout << "       ///  O   O  \\\\\\   " << endl;
    cout << "       ///    u    \\\\\\ " << endl;
    cout << "       //    \\\_/    \\\\  " << endl;
    cout << "          a      a      " << endl;
    cout << "       aaaaa   aaaaa    " << endl;
    cout << "     aaaaaaaaaaaaaaaaaaa" << endl;
    cout << "    aaaaaaa  aaaa   aaaaaa" << endl;
    cout << "   aaaaa               aaaa " << endl;
    cout << "  aaaaaa  aaaaa aaaaaaa  aaa" << endl;


    return 0; // signals the operating system that our program ended OK.
}